# partnerize — Python client for the Partnerize Brands API

Generated from the Partnerize Brands API OpenAPI spec (v1.4.99): **250 operations in 78 groups**, one class per API tag, each method with a docstring taken from the spec. Only dependency: `requests`.

## Install

```bash
pip install partnerize-0.1.0-py3-none-any.whl
# or from the source folder
pip install .
```

## Authenticate

Partnerize uses HTTP Basic auth: your **User Application Key** and **User API Key** (both are in the Partnerize console).

```python
from partnerize import PartnerizeClient

client = PartnerizeClient("YOUR_APPLICATION_KEY", "YOUR_USER_API_KEY")
# or set PARTNERIZE_APPLICATION_KEY / PARTNERIZE_API_KEY and call PartnerizeClient()
```

## Use

```python
networks  = client.networks.list_networks()
campaigns = client.campaigns.list_all_campaigns(network_id="1l1007802")
campaign  = client.campaigns.retrieve_a_campaign("111111l1")

client.campaigns.update_a_campaign("111111l1", body={"title": "Summer sale"})

# Any query parameter not in the spec, or extra headers
client.brand_conversions.brand_conversions("111111l1", "json", start_date="2026-10-01")

# Raw requests.Response (e.g. for CSV/PNG downloads, status codes, headers)
resp = client.campaigns.retrieve_a_campaign("111111l1", raw=True)

# Endpoints not in the spec
client.get("/some/new/endpoint", limit=10)
```

Path parameters are positional, everything else is keyword-only. JSON responses are decoded to dicts; CSV comes back as `str`, other binaries as `bytes`.

`ENDPOINTS.md` lists every group (`client.<group>`), method, HTTP verb and path. In Python, `help(client.campaigns)` shows the same with full parameter docs.

## Errors and retries

Non-2xx responses raise `AuthenticationError` (401/403), `NotFoundError` (404), `RateLimitError` (429), `ServerError` (5xx) or `APIError` — all have `.status_code`, `.message` and `.body`. 429 and 5xx are retried up to `max_retries` (default 3) with backoff, honouring `Retry-After`.

Options: `PartnerizeClient(..., base_url=..., timeout=60, max_retries=3, session=my_session)`.

## Regenerating

If Partnerize publishes a new spec: `python3 generate.py swagger.json .` (in `tools/`), then reinstall.
