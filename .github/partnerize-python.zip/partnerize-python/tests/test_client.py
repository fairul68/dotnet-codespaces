import base64
import json

import pytest
import requests
from requests.adapters import BaseAdapter

from partnerize import NotFoundError, PartnerizeClient
from partnerize.api import __all__ as GROUPS


class FakeAdapter(BaseAdapter):
    def __init__(self, status=200, body=None, ctype="application/json"):
        super().__init__()
        self.calls, self.status, self.body, self.ctype = [], status, body or {"ok": True}, ctype

    def send(self, request, **kw):
        self.calls.append(request)
        r = requests.Response()
        r.status_code = self.status
        r._content = json.dumps(self.body).encode() if "json" in self.ctype else self.body.encode()
        r.headers["Content-Type"] = self.ctype
        r.request, r.url = request, request.url
        return r

    def close(self):
        pass


def make(**kw):
    s = requests.Session()
    a = FakeAdapter(**kw)
    s.mount("https://", a)
    return PartnerizeClient("app", "key", session=s, max_retries=0), a


def test_auth_and_path_and_query():
    c, a = make()
    assert c.campaigns.list_all_campaigns(network_id="n1") == {"ok": True}
    req = a.calls[0]
    assert req.url == "https://api.partnerize.com/campaign?network_id=n1"
    assert req.headers["Authorization"] == "Basic " + base64.b64encode(b"app:key").decode()


def test_path_param_encoding_and_body():
    c, a = make()
    c.campaigns.update_a_campaign("a/b", body={"title": "x"})
    req = a.calls[0]
    assert req.method == "PUT" and req.url.endswith("/campaign/a%2Fb")
    assert json.loads(req.body) == {"title": "x"}


def test_errors():
    c, _ = make(status=404, body={"error": {"message": "nope"}})
    with pytest.raises(NotFoundError) as e:
        c.campaigns.retrieve_a_campaign("x")
    assert e.value.status_code == 404 and "nope" in str(e.value)


def test_all_groups_attached():
    c, _ = make()
    assert len(GROUPS) > 50
    for cls in GROUPS:
        assert any(type(v).__name__ == cls for v in vars(c).values()), cls
