"""Generate a requests-based Python SDK from an OpenAPI 3 spec (Partnerize Brands API).

Usage: python3 -I generate.py <spec.json> <out_dir>
"""
import json
import keyword
import re
import sys
import textwrap
from pathlib import Path

METHODS = ("get", "post", "put", "patch", "delete")
PKG = "partnerize"


def snake(s):
    s = re.sub(r"[^0-9A-Za-z]+", " ", s).strip()
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", s)
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", s)
    s = "_".join(w.lower() for w in s.split())
    if not s:
        s = "op"
    if s[0].isdigit():
        s = "_" + s
    if keyword.iskeyword(s) or s in ("self", "client", "body", "params", "headers", "raw"):
        s += "_"
    return s


def pascal(s):
    return "".join(w[:1].upper() + w[1:] for w in re.split(r"[^0-9A-Za-z]+", s) if w)


def clean(text, width=84):
    if not text:
        return ""
    text = re.sub(r"<[^>]+>", "", str(text)).replace("\\", "\\\\").replace('"""', "'''")
    out = []
    for para in text.strip().splitlines():
        out.extend(textwrap.wrap(para, width) or [""])
    return "\n".join(out)


def indent(text, n):
    pad = " " * n
    return "\n".join(pad + l if l.strip() else "" for l in text.splitlines())


def py_type(schema):
    t = (schema or {}).get("type")
    return {"integer": "int", "number": "float", "boolean": "bool", "array": "list",
            "object": "dict", "string": "str"}.get(t, "Any")


def main(spec_path, out_dir):
    spec = json.loads(Path(spec_path).read_text())

    def resolve(obj):
        while isinstance(obj, dict) and "$ref" in obj:
            cur = spec
            for k in obj["$ref"][2:].split("/"):
                cur = cur[k.replace("~1", "/").replace("~0", "~")]
            obj = cur
        return obj

    groups = {}  # tag -> list of op dicts
    for path, item in spec["paths"].items():
        shared = item.get("parameters", [])
        for method in METHODS:
            if method not in item:
                continue
            op = item[method]
            tag = (op.get("tags") or ["Default"])[0]
            fixed_query = {}
            clean_path = path
            if "?" in path:  # e.g. /x/{id}?{download=true}
                clean_path, q = path.split("?", 1)
                for kv in re.findall(r"\{?([^{}&]+)\}?", q):
                    if "=" in kv:
                        k, v = kv.split("=", 1)
                        fixed_query[k] = v
            params, seen = [], set()
            for p in [resolve(x) for x in op.get("parameters", []) + shared]:
                key = (p["name"], p["in"])
                if key in seen:
                    continue
                seen.add(key)
                params.append(p)
            groups.setdefault(tag, []).append(dict(
                method=method, path=clean_path, raw_path=path, op=op, params=params,
                fixed_query=fixed_query))

    tag_desc = {t["name"]: t.get("description", "") for t in spec.get("tags", [])}
    out = Path(out_dir) / PKG
    (out / "api").mkdir(parents=True, exist_ok=True)

    index = []  # (attr, cls, module, [(method_name, http, path, summary)])
    used_mods = set()
    for tag in sorted(groups):
        mod = snake(tag).strip("_") or "default"
        while mod in used_mods:
            mod += "_x"
        used_mods.add(mod)
        cls = pascal(tag) + "API"
        names = set()
        methods_src, listing = [], []
        for e in groups[tag]:
            op = e["op"]
            base = op.get("operationId") or op.get("summary") or f"{e['method']} {e['path']}"
            name = snake(base)
            if name in names:
                name = snake(f"{base} {e['method']}")
            n = 2
            while name in names:
                name = f"{snake(base)}_{n}"; n += 1
            names.add(name)

            path_params = [p for p in e["params"] if p["in"] == "path"]
            # keep path params in URL order
            order = re.findall(r"\{([^}]+)\}", e["path"])
            path_params.sort(key=lambda p: order.index(p["name"]) if p["name"] in order else 99)
            for nm in order:  # path placeholders missing from parameter list
                if nm not in [p["name"] for p in path_params]:
                    path_params.append({"name": nm, "in": "path", "schema": {"type": "string"}})
            other = [p for p in e["params"] if p["in"] in ("query", "header")]

            argnames = set()
            sig, pmap, qmap, hmap, pdoc = ["self"], [], [], [], []

            def argname(raw):
                a = snake(raw)
                while a in argnames:
                    a += "_"
                argnames.add(a)
                return a

            for p in path_params:
                a = argname(p["name"])
                sig.append(f"{a}: {py_type(p.get('schema'))}")
                pmap.append((p["name"], a))
                pdoc.append((a, p))
            body = op.get("requestBody")
            body = resolve(body) if body else None
            if body and body.get("required"):
                sig.append("body: Any")
            kw = []
            if body and not body.get("required"):
                kw.append("body: Any = None")
            for p in other:
                a = argname(p["name"])
                kw.append(f"{a}: Optional[{py_type(p.get('schema'))}] = None")
                (qmap if p["in"] == "query" else hmap).append((p["name"], a))
                pdoc.append((a, p))
            kw += ["params: Optional[Dict[str, Any]] = None",
                   "headers: Optional[Dict[str, str]] = None", "raw: bool = False"]
            sig.append("*")
            sig += kw

            doc = [clean(op.get("summary") or name)]
            if op.get("description"):
                doc += ["", clean(op["description"])]
            doc += ["", f"``{e['method'].upper()} {e['raw_path']}``"]
            if pdoc or body:
                doc += ["", "Args:"]
                for a, p in pdoc:
                    d = clean(p.get("description", ""), 76).replace("\n", "\n        ")
                    req = " (required)" if p.get("required") else ""
                    doc.append(f"    {a}: [{p['in']} ``{p['name']}``]{req} {d}".rstrip())
                if body:
                    d = clean(body.get("description", "JSON request body."), 76).replace("\n", "\n        ")
                    doc.append(f"    body: JSON request body (dict/list). {d}".rstrip())
                doc.append("    params: Extra query parameters merged into the request.")
                doc.append("    headers: Extra HTTP headers.")
                doc.append("    raw: Return the ``requests.Response`` instead of the decoded body.")
            if op.get("deprecated"):
                doc.insert(1, "\n.. deprecated:: Marked deprecated in the API spec.")

            lines = [f"def {name}({', '.join(sig)}) -> Any:",
                     indent('"""' + "\n".join(doc) + '\n"""', 4)]
            fmt = e["path"]
            for raw, a in pmap:
                fmt = fmt.replace("{" + raw + "}", "{" + a + "}")
            if pmap:
                lines.append(f"    path = {fmt!r}.format(" +
                             ", ".join(f"{a}=_q({a})" for _, a in pmap) + ")")
            else:
                lines.append(f"    path = {fmt!r}")
            lines.append("    query = " + "{" + ", ".join(
                [f"{k!r}: {v!r}" for k, v in e["fixed_query"].items()] +
                [f"{raw!r}: {a}" for raw, a in qmap]) + "}")
            lines.append("    hdrs = " + "{" + ", ".join(f"{raw!r}: {a}" for raw, a in hmap) + "}")
            lines.append(f"    return self._client.request({e['method'].upper()!r}, path, query=query, "
                         f"headers=hdrs, extra_params=params, extra_headers=headers, "
                         f"json={'body' if body else 'None'}, raw=raw)")
            methods_src.append(indent("\n".join(lines), 4))
            listing.append((name, e["method"].upper(), e["raw_path"], op.get("summary", "")))

        cdoc = clean(tag_desc.get(tag) or tag)
        src = (f'"""{tag} endpoints (generated from the Partnerize OpenAPI spec)."""\n'
               "from typing import Any, Dict, Optional\n\n"
               "from .._base import BaseAPI, _q\n\n\n"
               f"class {cls}(BaseAPI):\n" + indent('"""' + cdoc + '\n"""', 4) + "\n\n" +
               "\n\n".join(methods_src) + "\n")
        (out / "api" / f"{mod}.py").write_text(src)
        index.append((mod, cls, tag, listing))

    # api/__init__.py
    (out / "api" / "__init__.py").write_text(
        '"""Generated API groups, one class per spec tag."""\n' +
        "".join(f"from .{m} import {c}\n" for m, c, _, _ in index) +
        "\n__all__ = [" + ", ".join(repr(c) for _, c, _, _ in index) + "]\n")

    # groups wiring
    wiring = "\n".join(f"        self.{m} = {c}(self)" for m, c, _, _ in index)
    (out / "_groups.py").write_text(
        '"""Attaches every generated API group to the client."""\n'
        "from .api import *  # noqa: F401,F403\nfrom .api import __all__ as _ALL\n"
        "from . import api as _api\n\n\nclass GroupsMixin:\n    def _init_groups(self):\n" +
        wiring + "\n")

    # endpoint reference
    ref = ["# Endpoint reference", "",
           f"Generated from *{spec['info']['title']}* v{spec['info']['version']}. "
           f"{sum(len(l) for *_, l in index)} operations in {len(index)} groups.", ""]
    for m, c, tag, listing in index:
        ref += [f"## {tag} — `client.{m}`", "", "| Method | HTTP | Path | Summary |", "|---|---|---|---|"]
        for name, http, path, summ in listing:
            ref.append(f"| `{name}()` | {http} | `{path}` | {summ.replace('|', '/')} |")
        ref.append("")
    (Path(out_dir) / "ENDPOINTS.md").write_text("\n".join(ref))
    (out / "_meta.py").write_text(
        f"API_TITLE = {spec['info']['title']!r}\nAPI_VERSION = {spec['info']['version']!r}\n"
        f"DEFAULT_BASE_URL = {spec['servers'][0]['url']!r}\n")
    print(f"generated {sum(len(l) for *_, l in index)} operations in {len(index)} groups")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
