"""Exceptions raised by the Partnerize client."""


class PartnerizeError(Exception):
    """Base error for this package."""


class APIError(PartnerizeError):
    """The API returned a non-2xx response."""

    def __init__(self, status_code, message, response=None, body=None):
        super().__init__(f"HTTP {status_code}: {message}")
        self.status_code = status_code
        self.message = message
        self.response = response
        self.body = body


class AuthenticationError(APIError):
    """401 / 403."""


class NotFoundError(APIError):
    """404."""


class RateLimitError(APIError):
    """429 after retries were exhausted."""


class ServerError(APIError):
    """5xx after retries were exhausted."""


def raise_for_response(resp):
    if resp.ok:
        return
    try:
        body = resp.json()
    except ValueError:
        body = resp.text
    msg = body
    if isinstance(body, dict):
        err = body.get("error") or body.get("errors") or body.get("message") or body
        if isinstance(err, dict):
            err = err.get("message") or err
        msg = err
    cls = {401: AuthenticationError, 403: AuthenticationError, 404: NotFoundError,
           429: RateLimitError}.get(resp.status_code)
    if cls is None:
        cls = ServerError if resp.status_code >= 500 else APIError
    raise cls(resp.status_code, msg, response=resp, body=body)
