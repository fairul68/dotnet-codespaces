API_TITLE = 'Partnerize Brands API'
API_VERSION = '1.4.99'
DEFAULT_BASE_URL = 'https://api.partnerize.com'
