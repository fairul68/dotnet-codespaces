"""HTTP client for the Partnerize Brands API."""
import os
import time
from typing import Any, Dict, Optional

import requests

from ._groups import GroupsMixin
from ._meta import DEFAULT_BASE_URL
from .exceptions import PartnerizeError, raise_for_response

__all__ = ["PartnerizeClient"]


def _clean(d):
    return {k: v for k, v in (d or {}).items() if v is not None}


def _encode_query(query):
    """Drop None values; serialise booleans as true/false like the API expects."""
    out = {}
    for k, v in _clean(query).items():
        if isinstance(v, bool):
            v = "true" if v else "false"
        elif isinstance(v, (list, tuple)):
            v = ["true" if x is True else "false" if x is False else x for x in v]
        out[k] = v
    return out


class PartnerizeClient(GroupsMixin):
    """Client for the Partnerize Brands API.

    Authentication uses HTTP Basic with your *User Application Key* as the
    username and *User API Key* as the password. If not passed explicitly they
    are read from the ``PARTNERIZE_APPLICATION_KEY`` and ``PARTNERIZE_API_KEY``
    environment variables.

    Every tag in the API spec is exposed as an attribute, e.g.
    ``client.campaigns.list_all_campaigns()`` or
    ``client.conversions.<method>(...)``. See ENDPOINTS.md for the full list.

    Args:
        application_key: User Application Key.
        api_key: User API Key.
        base_url: Override the API host (default https://api.partnerize.com).
        timeout: Request timeout in seconds.
        max_retries: Retries on HTTP 429 / 5xx (with backoff, honouring Retry-After).
        session: Optional pre-configured ``requests.Session``.
    """

    def __init__(self, application_key: Optional[str] = None, api_key: Optional[str] = None,
                 *, base_url: Optional[str] = None, timeout: float = 60.0, max_retries: int = 3,
                 session: Optional[requests.Session] = None):
        application_key = application_key or os.environ.get("PARTNERIZE_APPLICATION_KEY")
        api_key = api_key or os.environ.get("PARTNERIZE_API_KEY")
        if not application_key or not api_key:
            raise PartnerizeError(
                "Missing credentials: pass application_key and api_key, or set "
                "PARTNERIZE_APPLICATION_KEY and PARTNERIZE_API_KEY.")
        self.base_url = (base_url or os.environ.get("PARTNERIZE_BASE_URL") or DEFAULT_BASE_URL).rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = session or requests.Session()
        self.session.auth = (application_key, api_key)
        self.session.headers.setdefault("Accept", "application/json")
        self.session.headers["User-Agent"] = "partnerize-python"
        self._init_groups()

    def request(self, method: str, path: str, *, query: Optional[Dict[str, Any]] = None,
                headers: Optional[Dict[str, str]] = None, extra_params=None, extra_headers=None,
                json: Any = None, raw: bool = False) -> Any:
        """Send a request to any endpoint. Returns decoded JSON, text (CSV) or bytes."""
        params = _encode_query({**(query or {}), **(extra_params or {})})
        hdrs = {**_clean(headers), **(extra_headers or {})}
        url = self.base_url + path
        attempt = 0
        while True:
            resp = self.session.request(method, url, params=params, headers=hdrs,
                                        json=json, timeout=self.timeout)
            if resp.status_code in (429, 500, 502, 503, 504) and attempt < self.max_retries:
                attempt += 1
                retry_after = resp.headers.get("Retry-After")
                try:
                    delay = float(retry_after) if retry_after else 2 ** (attempt - 1)
                except ValueError:
                    delay = 2 ** (attempt - 1)
                time.sleep(min(delay, 60))
                continue
            break
        raise_for_response(resp)
        if raw:
            return resp
        if resp.status_code == 204 or not resp.content:
            return None
        ctype = resp.headers.get("Content-Type", "")
        if "json" in ctype:
            return resp.json()
        if ctype.startswith("text/"):
            return resp.text
        return resp.content

    # convenience verbs for endpoints not in the spec
    def get(self, path, **params):
        return self.request("GET", path, query=params)

    def post(self, path, body=None, **params):
        return self.request("POST", path, query=params, json=body)

    def put(self, path, body=None, **params):
        return self.request("PUT", path, query=params, json=body)

    def delete(self, path, **params):
        return self.request("DELETE", path, query=params)

    def close(self):
        self.session.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
