"""Base helpers shared by the generated API groups."""
from urllib.parse import quote


def _q(value):
    """URL-encode a path parameter."""
    return quote(str(value), safe="")


class BaseAPI:
    def __init__(self, client):
        self._client = client
