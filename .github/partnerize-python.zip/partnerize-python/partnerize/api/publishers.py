"""Publishers endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class PublishersAPI(BaseAPI):
    """Partner management endpoints
    """

    def get_publishers(self, network_id: str, *, account_created: Optional[str] = None, campaign_ids: Optional[Any] = None, campaign_statuses: Optional[Any] = None, commission_group_ids: Optional[Any] = None, company_name: Optional[str] = None, fields: Optional[Any] = None, ids: Optional[Any] = None, include_discovery: Optional[str] = None, website_verified: Optional[bool] = None, limit: Optional[int] = None, locales: Optional[Any] = None, network_statuses: Optional[Any] = None, offset: Optional[int] = None, operating_countries: Optional[Any] = None, partner_collection_id: Optional[str] = None, promotional_countries: Optional[Any] = None, promotional_method_ids: Optional[Any] = None, publisher_email: Optional[str] = None, publisher_name: Optional[str] = None, publisher_tag_ids: Optional[Any] = None, publisher_website: Optional[str] = None, reporting_identifier: Optional[str] = None, search: Optional[str] = None, sort: Optional[str] = None, vertical_ids: Optional[Any] = None, recipient_status: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get publishers list

        Get Publishers for Network

        ``GET /v2/networks/{network_id}/publishers``

        Args:
            network_id: [path ``network_id``] (required) The publishers' network id
            account_created: [query ``account_created``] Date range for when partners signed up
            campaign_ids: [query ``campaign_ids``] The publishers' campaign ids
            campaign_statuses: [query ``campaign_statuses``] The publishers' campaign statuses
            commission_group_ids: [query ``commission_group_ids``] The publishers' commission group ids
            company_name: [query ``company_name``] The publishers' company name
            fields: [query ``fields``] CSV list of fields to be returned as part of the response
            ids: [query ``ids``] Filter by partner IDs
            include_discovery: [query ``include_discovery``] Whether to include partners with pending requests from brand discovery or
                invites from partner discovery
            website_verified: [query ``website_verified``] Whether to filter partners by their primary website domain verification
                status
            limit: [query ``limit``] The number of records to retrieve
            locales: [query ``locales``] The publishers' contact locale (locale codes), see
                https://api.partnerize.com/reference/locale
            network_statuses: [query ``network_statuses``] The publishers' network status. Choosing requested or invited will
                automatically enable the include_discovery option for convenience.
            offset: [query ``offset``] Starting position
            operating_countries: [query ``operating_countries``] The publishers' operating countries (country isos), see
                https://api.partnerize.com/reference/country
            partner_collection_id: [query ``partner_collection_id``] Filter by partner collection ID
            promotional_countries: [query ``promotional_countries``] The publishers' promotional countries (country isos), see
                https://api.partnerize.com/reference/country
            promotional_method_ids: [query ``promotional_method_ids``] The publishers' promotional methods , see
                https://api.partnerize.com/reference/promotional_method
            publisher_email: [query ``publisher_email``]
            publisher_name: [query ``publisher_name``] Search by the publishers' company name, falling back the publisher name
            publisher_tag_ids: [query ``publisher_tag_ids``]
            publisher_website: [query ``publisher_website``]
            reporting_identifier: [query ``reporting_identifier``]
            search: [query ``search``] Search for matching publishers
            sort: [query ``sort``] Order results
            vertical_ids: [query ``vertical_ids``] The publishers' verticals, see https://api.partnerize.com/reference/vertical
            recipient_status: [query ``recipient_status``] Accepts a communication ID. Adds a flag into the response whether publishers
                are on that communication's recipient list
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/publishers'.format(network_id=_q(network_id))
        query = {'account_created': account_created, 'campaign_ids': campaign_ids, 'campaign_statuses': campaign_statuses, 'commission_group_ids': commission_group_ids, 'company_name': company_name, 'fields': fields, 'ids': ids, 'include_discovery': include_discovery, 'website_verified': website_verified, 'limit': limit, 'locales': locales, 'network_statuses': network_statuses, 'offset': offset, 'operating_countries': operating_countries, 'partner_collection_id': partner_collection_id, 'promotional_countries': promotional_countries, 'promotional_method_ids': promotional_method_ids, 'publisher_email': publisher_email, 'publisher_name': publisher_name, 'publisher_tag_ids': publisher_tag_ids, 'publisher_website': publisher_website, 'reporting_identifier': reporting_identifier, 'search': search, 'sort': sort, 'vertical_ids': vertical_ids, 'recipient_status': recipient_status}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def export_publishers(self, network_id: str, *, body: Any = None, accept: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Export publishers

        Export publishers for a network

        ``POST /v2/networks/{network_id}/publishers.csv``

        Args:
            network_id: [path ``network_id``] (required) The publishers' network id
            accept: [header ``Accept``]
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/publishers.csv'.format(network_id=_q(network_id))
        query = {}
        hdrs = {'Accept': accept}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def get_publisher_details(self, network_id: str, publisher_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get publisher details

        Get Publishers Details for Network

        ``GET /v2/networks/{network_id}/publishers/{publisher_id}``

        Args:
            network_id: [path ``network_id``] (required) The publishers' network id
            publisher_id: [path ``publisher_id``] (required) The publisher id
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/publishers/{publisher_id}'.format(network_id=_q(network_id), publisher_id=_q(publisher_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_publishers_ids(self, network_id: str, *, account_created: Optional[str] = None, campaign_ids: Optional[Any] = None, campaign_statuses: Optional[Any] = None, commission_group_ids: Optional[Any] = None, company_name: Optional[str] = None, ids: Optional[Any] = None, include_discovery: Optional[str] = None, website_verified: Optional[bool] = None, limit: Optional[int] = None, locales: Optional[Any] = None, network_statuses: Optional[Any] = None, offset: Optional[int] = None, operating_countries: Optional[Any] = None, promotional_countries: Optional[Any] = None, promotional_method_ids: Optional[Any] = None, publisher_email: Optional[str] = None, publisher_name: Optional[str] = None, publisher_tag_ids: Optional[Any] = None, publisher_website: Optional[str] = None, reporting_identifier: Optional[str] = None, search: Optional[str] = None, sort: Optional[str] = None, vertical_ids: Optional[Any] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get publishers ids list

        Get a list of publisher ids

        ``GET /v2/networks/{network_id}/publishers/ids``

        Args:
            network_id: [path ``network_id``] (required) The publishers' network id
            account_created: [query ``account_created``] Date range for when partners signed up
            campaign_ids: [query ``campaign_ids``] The publishers' campaign ids
            campaign_statuses: [query ``campaign_statuses``] The publishers' campaign statuses
            commission_group_ids: [query ``commission_group_ids``] The publishers' commission group ids
            company_name: [query ``company_name``] The publishers' company name
            ids: [query ``ids``] Filter by partner IDs
            include_discovery: [query ``include_discovery``] Whether to include partners with pending requests from brand discovery or
                invites from partner discovery
            website_verified: [query ``website_verified``] Whether to filter partners by their primary website domain verification
                status
            limit: [query ``limit``] The number of records to retrieve
            locales: [query ``locales``] The publishers' contact locale (locale codes), see
                https://api.partnerize.com/reference/locale
            network_statuses: [query ``network_statuses``] The publishers' network status. Choosing requested or invited will
                automatically enable the include_discovery option for convenience.
            offset: [query ``offset``] Starting position
            operating_countries: [query ``operating_countries``] The publishers' operating countries (country isos), see
                https://api.partnerize.com/reference/country
            promotional_countries: [query ``promotional_countries``] The publishers' promotional countries (country isos), see
                https://api.partnerize.com/reference/country
            promotional_method_ids: [query ``promotional_method_ids``] The publishers' promotional methods , see
                https://api.partnerize.com/reference/promotional_method
            publisher_email: [query ``publisher_email``]
            publisher_name: [query ``publisher_name``] Search by the publishers' company name, falling back the publisher name
            publisher_tag_ids: [query ``publisher_tag_ids``]
            publisher_website: [query ``publisher_website``]
            reporting_identifier: [query ``reporting_identifier``]
            search: [query ``search``] Search for matching publishers
            sort: [query ``sort``] Order results
            vertical_ids: [query ``vertical_ids``] The publishers' verticals, see https://api.partnerize.com/reference/vertical
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/publishers/ids'.format(network_id=_q(network_id))
        query = {'account_created': account_created, 'campaign_ids': campaign_ids, 'campaign_statuses': campaign_statuses, 'commission_group_ids': commission_group_ids, 'company_name': company_name, 'ids': ids, 'include_discovery': include_discovery, 'website_verified': website_verified, 'limit': limit, 'locales': locales, 'network_statuses': network_statuses, 'offset': offset, 'operating_countries': operating_countries, 'promotional_countries': promotional_countries, 'promotional_method_ids': promotional_method_ids, 'publisher_email': publisher_email, 'publisher_name': publisher_name, 'publisher_tag_ids': publisher_tag_ids, 'publisher_website': publisher_website, 'reporting_identifier': reporting_identifier, 'search': search, 'sort': sort, 'vertical_ids': vertical_ids}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def post_publisher_collection(self, network_id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create publisher collection

        Create publisher collection

        ``POST /v2/networks/{network_id}/partner-collections``

        Args:
            network_id: [path ``network_id``] (required) The publishers' network id
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/partner-collections'.format(network_id=_q(network_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_publisher_collection(self, network_id: str, collection_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete publisher collection

        ``DELETE /v2/networks/{network_id}/partner-collections/{collection-id}``

        Args:
            network_id: [path ``network_id``] (required) The publishers' network id
            collection_id: [path ``collection-id``] (required) The collection id
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/partner-collections/{collection_id}'.format(network_id=_q(network_id), collection_id=_q(collection_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def post_publisher_collection_partners(self, network_id: str, collection_id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Add publishers to a collection

        ``POST /v2/networks/{network_id}/partner-collections/{collection-id}/partners``

        Args:
            network_id: [path ``network_id``] (required) The publishers' network id
            collection_id: [path ``collection-id``] (required) The collection id
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/partner-collections/{collection_id}/partners'.format(network_id=_q(network_id), collection_id=_q(collection_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_publisher_collection_partners(self, network_id: str, collection_id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Remove publishers from a collection

        ``DELETE /v2/networks/{network_id}/partner-collections/{collection-id}/partners``

        Args:
            network_id: [path ``network_id``] (required) The publishers' network id
            collection_id: [path ``collection-id``] (required) The collection id
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/partner-collections/{collection_id}/partners'.format(network_id=_q(network_id), collection_id=_q(collection_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
