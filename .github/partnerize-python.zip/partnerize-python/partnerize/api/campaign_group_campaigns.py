"""Campaign Group Campaigns endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CampaignGroupCampaignsAPI(BaseAPI):
    """Campaigns can be grouped together.
    """

    def retrieve_a_list_of_campaigns_in_a_campaign_group(self, campaign_group_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve a List of Campaigns in a Campaign Group

        Retrieve a List of Campaigns in a Campaign Group by id

        ``GET /v3/brand/campaign-groups/{campaign_group_id}/campaigns``

        Args:
            campaign_group_id: [path ``campaign_group_id``] (required) Id of the campaign group
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/campaign-groups/{campaign_group_id}/campaigns'.format(campaign_group_id=_q(campaign_group_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
