"""Traffic Sources endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class TrafficSourcesAPI(BaseAPI):
    """Traffic Sources
    """

    def list_traffic_sources(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Traffic Sources

        List all available Traffic Source types.

        ``GET /reference/traffic_source``
        """
        path = '/reference/traffic_source'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
