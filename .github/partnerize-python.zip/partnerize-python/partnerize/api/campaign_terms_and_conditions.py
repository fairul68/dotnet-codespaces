"""Campaign Terms and Conditions endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CampaignTermsAndConditionsAPI(BaseAPI):
    """Campaign Terms and Conditions
    """

    def read_custom_terms(self, campaign_id: str, terms_id: str, download: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve Campaign Terms and Conditions

        Retrieve the Campaign Terms and Conditions for a given Terms and Conditions id. You
        can download them by specifying the `download=true` query string parameter.

        ``GET /campaign/{campaign_id}/custom_terms/{terms_id}?{download=true}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            terms_id: [path ``terms_id``] (required) ID of Campaign Terms and Conditions
            download: [path ``download``] Use this query string parameter to indicate the terms and conditions should
                be downloaded as a file
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/custom_terms/{terms_id}'.format(campaign_id=_q(campaign_id), terms_id=_q(terms_id), download=_q(download))
        query = {'download': 'true'}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
