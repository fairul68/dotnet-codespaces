"""In-Cart endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class InCartAPI(BaseAPI):
    """Define a period leading up to the time of purchase where clicks will be ignored and
    not attributed with a commission. Helps prevent last-click poaching.
    """

    def get_v2_attribution_in_cart(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List In-Cart Settings

        Get the In-Cart settings for the given Campaign

        ``GET /v2/campaigns/{campaignId}/attribution/in-cart``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/in-cart'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def post_v2_attribution_in_cart(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update In-Cart Settings

        Update the In-Cart settings for the Given Campaign

        ``PATCH /v2/campaigns/{campaignId}/attribution/in-cart``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/in-cart'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
