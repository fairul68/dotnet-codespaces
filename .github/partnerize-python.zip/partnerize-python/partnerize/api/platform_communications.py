"""Platform Communications endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class PlatformCommunicationsAPI(BaseAPI):
    """Platform Communications
    """

    def get_platform_communication_events(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get platform events list

        Returns the available events for triggering platform communications

        ``GET /v2/platform-communications/events``
        """
        path = '/v2/platform-communications/events'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_platform_communications(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get platform communications list

        Returns all existing platform communications

        ``GET /v2/platform-communications``
        """
        path = '/v2/platform-communications'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_platform_communication(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create platform communication

        Creates a platform communication that can be triggered automatically when a given
        event occurs

        ``POST /v2/platform-communications``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/platform-communications'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def update_platform_communication(self, id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update an existing platform communication content

        Updates an existing platform communication content

        ``PATCH /v2/platform-communications/{id}``

        Args:
            id: [path ``id``]
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/platform-communications/{id}'.format(id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_platform_communication(self, id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Deletes an existing platform communication

        Deletes an existing platform communication

        ``DELETE /v2/platform-communications/{id}``

        Args:
            id: [path ``id``] (required) The ID of the platform communication to be deleted
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/platform-communications/{id}'.format(id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_platform_communication_content(self, id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Returns the content of a platform communication

        Returns the HTML content of an existing platform communication.

        ``GET /v2/platform-communications/{id}/content``

        Args:
            id: [path ``id``] (required) The ID of the platform communication
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/platform-communications/{id}/content'.format(id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def validate_platform_communication_content(self, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Validate content

        A helper endpoint which can be used to validate the html for a platform
        communication

        ``POST /v2/platform-communications/validate-content``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/platform-communications/validate-content'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
