"""Meta Fields endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class MetaFieldsAPI(BaseAPI):
    """Meta Fields Endpoints
    """

    def get_meta_fields(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Campaign Meta Fields

        Determine the meta fields available when filtering commissions. This endpoint
        returns either the default set of meta fields, or a custom set which replaces the
        default fields.

        ``GET /v2/campaigns/{campaignId}/meta-fields``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the commission tiers for
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/meta-fields'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_tier_meta_fields(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Tier Meta Fields

        Returns the meta fields available when defining commission tiers. This endpoint
        returns campaign meta fields, plus meta fields that can be used to refine commission
        tiers, but not commission rates.

        ``GET /v2/campaigns/{campaignId}/commissions/tiers/meta-fields``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the commission tiers for
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/tiers/meta-fields'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
