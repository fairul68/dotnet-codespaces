"""Metrics endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class MetricsAPI(BaseAPI):
    """Metrics
    """

    def get_fraud_metrics(self, campaign_id: str, *, start_date: Optional[str] = None, end_date: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Metrics

        Get Fraud Metrics for the campaign, including a count of each

        ``GET /v2/campaigns/{campaign_id}/fraud/metrics``

        Args:
            campaign_id: [path ``campaign_id``] (required) Campaign ID
            start_date: [query ``start_date``] Only count incidents after this date.
            end_date: [query ``end_date``] Only count incidents before this date.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/fraud/metrics'.format(campaign_id=_q(campaign_id))
        query = {'start_date': start_date, 'end_date': end_date}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
