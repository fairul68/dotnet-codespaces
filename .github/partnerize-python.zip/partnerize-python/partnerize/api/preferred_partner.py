"""Preferred Partner endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class PreferredPartnerAPI(BaseAPI):
    """Campaigns can have one preferred partner at any time. A sale will be attributed to a
    preferred partner if they contribute any clicks to that sale.
    """

    def get_v2_attribution_preferred_partner(self, campaign_id: str, *, limit: Optional[int] = None, offset: Optional[int] = None, name: Optional[str] = None, dates: Optional[str] = None, statuses: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List All Preferred Partners

        Show a list of all configured preferred partners. May be filtered with several
        filters.

        ``GET /v2/campaigns/{campaignId}/attribution/preferred-partners``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            limit: [query ``limit``] Used to limit the response to a number of results. Defaults to 20
            offset: [query ``offset``] Used to offset the results we're returning
            name: [query ``name``] Search for partner by name. Alphanumeric with dashes and underscores
            dates: [query ``dates``] Search for preferred partners within a date range. Comma separated start and
                end date
            statuses: [query ``statuses``] A comma separated list of statuses to return results for
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/preferred-partners'.format(campaign_id=_q(campaign_id))
        query = {'limit': limit, 'offset': offset, 'name': name, 'dates': dates, 'statuses': statuses}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def post_v2_campaigns_campaign_id_attribution_preferred_partners(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create Preferred Partner

        Create a Preferred Partner configuration

        ``POST /v2/campaigns/{campaignId}/attribution/preferred-partners``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/preferred-partners'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def bulk_delete_v2_campaigns_campaign_id_attribution_preferred_partners(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete Preferred Partners

        Delete Preferred Partners. This is only possible if the Preferred Partners are
        scheduled, otherwise an error will occur.

        ``DELETE /v2/campaigns/{campaignId}/attribution/preferred-partners``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/preferred-partners'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def get_v2_campaigns_campaign_id_attribution_preferred_partners_id(self, campaign_id: str, id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get a Preferred Partner

        Get a Preferred Partner by ID

        ``GET /v2/campaigns/{campaignId}/attribution/preferred-partners/{id}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            id: [path ``id``] (required) The Preferred Partner ID
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/preferred-partners/{id}'.format(campaign_id=_q(campaign_id), id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def patch_v2_campaigns_campaign_id_attribution_preferred_partners_id(self, campaign_id: str, id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update a Preferred Partner

        Update Preferred Partner

        ``PATCH /v2/campaigns/{campaignId}/attribution/preferred-partners/{id}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            id: [path ``id``] (required) The Preferred Partner ID
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/preferred-partners/{id}'.format(campaign_id=_q(campaign_id), id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_v2_campaigns_campaign_id_attribution_preferred_partners_id(self, campaign_id: str, id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete a Preferred Partner

        Delete a Preferred Partner. This is only possible if the Preferred Partner is
        scheduled, otherwise an error will occur.

        ``DELETE /v2/campaigns/{campaignId}/attribution/preferred-partners/{id}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            id: [path ``id``] (required) The Preferred Partner ID
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/preferred-partners/{id}'.format(campaign_id=_q(campaign_id), id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
