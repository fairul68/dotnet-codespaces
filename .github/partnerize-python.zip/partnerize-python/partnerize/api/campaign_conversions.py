"""Campaign Conversions endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CampaignConversionsAPI(BaseAPI):
    """Campaign Conversions
    """

    def v3_conversion_bulk_update(self, campaign_id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Bulk update of conversions

        Allows for conversion update operations to be performed on conversions within a
        particular campaign. This can be achieved using the `conversion_id`,
        `conversion_item_id` or `conversion_reference` identifiers depending on what works
        best in the situation.

        As well as `status`, fields such as references, `metadata`, `customer_type`,
        `traffic_source_id`, `item_value`, `category` and `sku` can be updated. See the
        request body schema for the full list of fields at each level, and the request
        samples for examples.

        Any changes to `status` at the `conversions` or `conversion_references` level will
        be applied to all items within that conversion, provided the individual item is
        allowed to be updated. Should you want to be more explicit with `status` (or any
        other field) updates then the `conversion_items` key allows this.

        **Note** Only one of the accepted parameters to the payload (`conversions`,
        `conversion_items`, or `conversion_references`) can be used at once, each allowing a
        maximum of 100,000 items.

        Deprecates `POST /campaign/{campaignID}/conversion`

        ``POST /v3/brand/campaigns/{campaignID}/conversions/bulk``

        Args:
            campaign_id: [path ``campaignID``] (required) Id of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/campaigns/{campaign_id}/conversions/bulk'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
