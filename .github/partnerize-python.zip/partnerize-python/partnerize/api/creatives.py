"""Creatives endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CreativesAPI(BaseAPI):
    """A Brand may wish to offer pre-generated _Creative_ so that the Partners can
    advertise the Brand easily. It is possible to categorise Creative with tags and
    there are 3 distinct Creative formats: Image, HTML and Text. Brands can organise
    their Creatives in a flexible structure by using _Creative Tags_.
    """

    def list_all_creatives_for_a_campaign(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Creatives for a Campaign

        List and view all Creatives for the specified Campaign.

        ``GET /campaign/{campaign_id}/creative``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/creative'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_campaign_creatives(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create Campaign Creatives

        Create one or more Creatives against the Campaign entity. Each Creative is sent as
        an array within a top level `creatives` array.

        ``POST /campaign/{campaign_id}/creative``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/creative'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def update_campaign_creatives(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update Campaign Creatives

        Update one or more Creatives against the Campaign entity. Each Creative is sent as
        an array within a top level `creatives` array and must contain its associated
        `creative_id`.

        ``PUT /campaign/{campaign_id}/creative``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/creative'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('PUT', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def list_all_creative_tags_for_campaign(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Creative Tags for Campaign

        View all Creative Tags for the specified Campaign.

        ``GET /campaign/{campaign_id}/creative/tags``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/creative/tags'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_campaign_creative_tags(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create Campaign Creative Tags

        Create one or more Creative Tags against the Campaign entity. Each Tag is sent as an
        array within a top level `tags` array.

        ``POST /campaign/{campaign_id}/creative/tags``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/creative/tags'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def update_campaign_creative_tags(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update Campaign Creative Tags

        Update one or more Creative Tags against the Campaign entity. Each Tag is sent as an
        array within a top level `tags` array and must contain its associated
        `creative_tag_id`.

        ``PUT /campaign/{campaign_id}/creative/tags``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/creative/tags'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('PUT', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_campaign_creative_tags(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete Campaign Creative Tags

        Delete one or more Creative Tags against the Campaign entity. Each Tag is sent as an
        array within a top level `tags` array and must contain its associated
        `creative_tag_id`.

        ``DELETE /campaign/{campaign_id}/creative/tags``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/creative/tags'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def list_all_creatives_for_a_campaign_by_tags(self, campaign_id: str, *, tags: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Creatives for a Campaign by Tags

        List and view all Creatives for the specified Campaign and filter by tags.

        ``GET /campaign/{campaign_id}/creative_tags/creative``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            tags: [query ``tags[]``] An array of tags IDs to filter the creatives by
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/creative_tags/creative'.format(campaign_id=_q(campaign_id))
        query = {'tags[]': tags}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
