"""Impressions endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class ImpressionsAPI(BaseAPI):
    """Endpoints for analysing impression data
    """

    def post_impressions_count(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Count

        Returns aggregated metrics derived from impressions.

        This endpoint is ideal for creating dashboard widgets, or for creating a summary of
        tabulated data from the explode endpoint.

        ``POST /v3/brand/analytics/impressions/count``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/analytics/impressions/count'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def post_impressions_explode(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Explode

        Returns aggregated metrics derived from impressions, grouped by ID and name of one
        or many dimensions. This endpoint is ideal for
        fetching data to be shown in a table. You can combine it with the count endpoint to
        fetch data for a totals row.

        If `order_by` is requested on a metric, the metric values will be added to the
        results, even if not requested.

        When grouping by `date`, the `interval` will define the length of each date group.

        ``POST /v3/brand/analytics/impressions/explode``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/analytics/impressions/explode'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def post_impressions_filter(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Filter

        This endpoint is ideal for fetching a list of available dimensions for a dropdown
        list.

        If `order_by` is requested on a metric, the metric values will be added to the
        results.

        ``POST /v3/brand/analytics/impressions/filter``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/analytics/impressions/filter'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def post_impressions_timeseries(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Timeseries

        Returns aggregated metrics derived from impressions, grouped by time intervals.

        This endpoint is ideal for creating charts where the x-axis is time.

        ``POST /v3/brand/analytics/impressions/timeseries``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/analytics/impressions/timeseries'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
