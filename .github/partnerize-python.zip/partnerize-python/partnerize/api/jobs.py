"""Jobs endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class JobsAPI(BaseAPI):
    """Jobs
    """

    def get_jobs(self, *, type: Optional[str] = None, reference: Optional[str] = None, offset: Optional[int] = None, limit: Optional[int] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get a list of jobs for the user

        Returns a list of jobs for the api user

        ``GET /v3/jobs``

        Args:
            type: [query ``type``] Job type to filter by
            reference: [query ``reference``] Job reference to filter by. Performs a partial match, eg "partner" would
                match a reference of "partnerize",
                "dance-partner" and "partner".
            offset: [query ``offset``] Pagination offset
            limit: [query ``limit``] Pagination limit
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/jobs'
        query = {'type': type, 'reference': reference, 'offset': offset, 'limit': limit}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_job(self, job_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get a single job

        Returns information about a single v3 job by the given ID

        ``GET /v3/jobs/{jobID}``

        Args:
            job_id: [path ``jobID``] (required) Id of the job
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/jobs/{job_id}'.format(job_id=_q(job_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_job_tasks(self, job_id: str, *, offset: Optional[int] = None, limit: Optional[int] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get tasks for a job

        Returns a list of tasks for a given job

        ``GET /v3/jobs/{jobID}/tasks``

        Args:
            job_id: [path ``jobID``] (required) Id of the job
            offset: [query ``offset``] Pagination offset
            limit: [query ``limit``] Pagination limit
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/jobs/{job_id}/tasks'.format(job_id=_q(job_id))
        query = {'offset': offset, 'limit': limit}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_task(self, job_id: str, task_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get detailed task information

        Returns detailed information for a given task

        ``GET /v3/jobs/{jobID}/tasks/{taskID}``

        Args:
            job_id: [path ``jobID``] (required) Id of the job
            task_id: [path ``taskID``] (required) Id of the task
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/jobs/{job_id}/tasks/{task_id}'.format(job_id=_q(job_id), task_id=_q(task_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def replay_job(self, job_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Replay a job

        Resubmits a job in to the queue for re-processing. Only jobs of type
        `conversion_bulk_update` can be replayed.

        ``POST /v3/jobs/{jobID}/replay``

        Args:
            job_id: [path ``jobID``] (required) Id of the job
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/jobs/{job_id}/replay'.format(job_id=_q(job_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def replay_job_post(self, job_id: str, task_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Replay a job

        Resubmits a task in to the queue for re-processing. Only tasks of type
        `conversion_bulk_update` can be replayed.

        ``POST /v3/jobs/{jobID}/tasks/{taskID}/replay``

        Args:
            job_id: [path ``jobID``] (required) Id of the job
            task_id: [path ``taskID``] (required) Id of the task
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/jobs/{job_id}/tasks/{task_id}/replay'.format(job_id=_q(job_id), task_id=_q(task_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
