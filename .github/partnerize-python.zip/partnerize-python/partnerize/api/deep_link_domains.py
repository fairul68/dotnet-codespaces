"""Deep link domains endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class DeepLinkDomainsAPI(BaseAPI):
    """Endpoints dealing with the management of tracking deep link domains
    """

    def get_deeplink_domains(self, brand: str, *, limit: Optional[int] = None, offset: Optional[int] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Fetches allowed deeplink domains for the given brand.

        Fetches allowed deeplink domains for a given brand. Results are ordered by domain
        name in ascending order.

        ``GET /v3/brand/{brand}/deeplink-domains``

        Args:
            brand: [path ``brand``] (required) Brand ID to get allowed domains for
            limit: [query ``limit``] Limits the number of results returned. Defaults to 20
            offset: [query ``offset``] Offsets the results returned
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/{brand}/deeplink-domains'.format(brand=_q(brand))
        query = {'limit': limit, 'offset': offset}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def add_deeplink_domains(self, brand: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Adds allowed deeplink domains for the given brand.

        Adds a number of allowed deeplink domains for the given Brand. A maximum of 100
        domains can be added at once.

        ``PATCH /v3/brand/{brand}/deeplink-domains``

        Args:
            brand: [path ``brand``] (required) Brand ID to modify allowed domains for
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/{brand}/deeplink-domains'.format(brand=_q(brand))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_deeplink_domains(self, brand: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Removes allowed deeplink domains for the given brand.

        Removes a number of allowed deeplink domains for the given Brand. A maximum of 100
        domains can be removed at once.

        ``DELETE /v3/brand/{brand}/deeplink-domains``

        Args:
            brand: [path ``brand``] (required) Brand ID to remove allowed domains for
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/{brand}/deeplink-domains'.format(brand=_q(brand))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
