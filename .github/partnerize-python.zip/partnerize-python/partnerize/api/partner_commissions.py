"""Partner Commissions endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class PartnerCommissionsAPI(BaseAPI):
    """Partner Commissions Endpoints
    """

    def get_publisher_commissions(self, campaign_id: str, publisher_id: str, *, status: Optional[str] = None, type: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get Partner Commissions

        Get Partner Commissions. Active and Scheduled Commissions will be returned

        ``GET /v2/campaigns/{campaignId}/publishers/{publisherId}/commissions``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign for which to get partner commission rates
            publisher_id: [path ``publisherId``] (required) The ID of a partner on a campaign
            status: [query ``status``] Retrieve Commissions with a specifc Status
            type: [query ``type``] Retrieve Commissions of a specific Commission Type
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/publishers/{publisher_id}/commissions'.format(campaign_id=_q(campaign_id), publisher_id=_q(publisher_id))
        query = {'status': status, 'type': type}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_publisher_commissions_default(self, campaign_id: str, publisher_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get Partner Default Commissions

        Get Partner Default Commissions

        ``GET /v2/campaigns/{campaignId}/publishers/{publisherId}/commissions/default``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign for which to get partner commission rates
            publisher_id: [path ``publisherId``] (required) The ID of a Partner on a campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/publishers/{publisher_id}/commissions/default'.format(campaign_id=_q(campaign_id), publisher_id=_q(publisher_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_publisher_commissions_campaign(self, campaign_id: str, publisher_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Partner Commissions For Specific Campaign

        This endpoint lists partner commissions for the given partner and campaign.

        ``GET /v2/campaigns/{campaignId}/publishers/{publisherId}/commissions/campaign``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the Partner commissions for
            publisher_id: [path ``publisherId``] (required) The ID of the Partner to list commissions for
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/publishers/{publisher_id}/commissions/campaign'.format(campaign_id=_q(campaign_id), publisher_id=_q(publisher_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_publisher_commissions_voucher(self, campaign_id: str, publisher_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Partner Voucher Commissions For Specific Campaign

        This endpoint lists partner voucher commissions for the given partner and campaign.

        ``GET /v2/campaigns/{campaignId}/publishers/{publisherId}/commissions/voucher``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the partner commissions for
            publisher_id: [path ``publisherId``] (required) The ID of the partner to list commissions for
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/publishers/{publisher_id}/commissions/voucher'.format(campaign_id=_q(campaign_id), publisher_id=_q(publisher_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_publisher_commissions_promotion(self, campaign_id: str, publisher_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Partner Promotional Commissions For Specific Campaign

        This endpoint lists partner promotional commissions for the given partner and
        campaign.

        ``GET /v2/campaigns/{campaignId}/publishers/{publisherId}/commissions/promotion``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the Partner commissions for
            publisher_id: [path ``publisherId``] (required) The ID of the Partner to list commissions for
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/publishers/{publisher_id}/commissions/promotion'.format(campaign_id=_q(campaign_id), publisher_id=_q(publisher_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_publisher_commissions_tier(self, campaign_id: str, publisher_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Partner Tiered Commissions For Specific Campaign

        This endpoint lists partner tiered commissions for the given partner and campaign.

        ``GET /v2/campaigns/{campaignId}/publishers/{publisherId}/commissions/tier``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the Partner commissions for
            publisher_id: [path ``publisherId``] (required) The ID of the Partner to list commissions for
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/publishers/{publisher_id}/commissions/tier'.format(campaign_id=_q(campaign_id), publisher_id=_q(publisher_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_active_publisher_commissions(self, campaign_id: str, publisher_id: str, *, at: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Active Partner Commissions

        This endpoint lists all active commissions including default, standard, voucher and
        promotional commissions for a partner a campaign

        ``GET /v2/campaigns/{campaignId}/publishers/{publisherId}/commissions/active``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the commissions for
            publisher_id: [path ``publisherId``] (required) The ID of a Partner on a campaign
            at: [query ``at``] The date and time to show the active commissions for. If not set defaults to
                now.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/publishers/{publisher_id}/commissions/active'.format(campaign_id=_q(campaign_id), publisher_id=_q(publisher_id))
        query = {'at': at}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
