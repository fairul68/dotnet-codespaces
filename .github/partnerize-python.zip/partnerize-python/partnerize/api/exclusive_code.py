"""Exclusive Code endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class ExclusiveCodeAPI(BaseAPI):
    """Exclusive codes are assigned to a partner. If a partner’s exclusive code is
    redeemed, the partner wins the sale - even if they don’t contribute any clicks.
    """

    def get_v2_attribution_exclusive_codes(self, campaign_id: str, *, limit: Optional[int] = None, offset: Optional[int] = None, query: Optional[str] = None, dates: Optional[str] = None, statuses: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List All Exclusive Codes

        Show a list of all configured exclusive codes. May be filtered with several filters.

        ``GET /v2/campaigns/{campaignId}/attribution/exclusive-codes``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            limit: [query ``limit``] Used to limit the response to a number of results
            offset: [query ``offset``] Used to offset the results we're returning
            query: [query ``query``] Search for specific codes or partner names
            dates: [query ``dates``] Search for codes within a date-time range. Comma separated start and end
                date-times
            statuses: [query ``statuses``] A comma separated list of statuses to return results for
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/exclusive-codes'.format(campaign_id=_q(campaign_id))
        query = {'limit': limit, 'offset': offset, 'query': query, 'dates': dates, 'statuses': statuses}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def post_v2_campaigns_campaign_id_attribution_exclusive_codes(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create an Exclusive Code

        Create an Exclusive Code configuration

        ``POST /v2/campaigns/{campaignId}/attribution/exclusive-codes``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/exclusive-codes'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def bulk_delete_v2_campaigns_campaign_id_attribution_exclusive_codes(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete Exclusive Codes

        Delete Exclusive Codes. This is only possible if the Exclusive Codes are scheduled,
        otherwise an error will occur.

        ``DELETE /v2/campaigns/{campaignId}/attribution/exclusive-codes``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/exclusive-codes'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def get_campaigns_campaign_id_attribution_exclusive_codes_id(self, campaign_id: str, id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get an Exclusive Code

        Get an Exclusive Code instance

        ``GET /v2/campaigns/{campaignId}/attribution/exclusive-codes/{id}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            id: [path ``id``] (required) The ID of the Exclusive Code
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/exclusive-codes/{id}'.format(campaign_id=_q(campaign_id), id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def patch_v2_campaigns_campaign_id_attribution_exclusive_codes_id(self, campaign_id: str, id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update an Exclusive Code

        Update an Exclusive Code. All request body properties are optional but at least one
        must be specified for update.

        ``PATCH /v2/campaigns/{campaignId}/attribution/exclusive-codes/{id}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            id: [path ``id``] (required) The ID of the Exclusive Code
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/exclusive-codes/{id}'.format(campaign_id=_q(campaign_id), id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_campaigns_campaign_id_attribution_exclusive_codes_id(self, campaign_id: str, id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete an Exclusive Code

        Delete an Exclusive Code

        ``DELETE /v2/campaigns/{campaignId}/attribution/exclusive-codes/{id}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            id: [path ``id``] (required) The ID of the Exclusive Code
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/exclusive-codes/{id}'.format(campaign_id=_q(campaign_id), id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
