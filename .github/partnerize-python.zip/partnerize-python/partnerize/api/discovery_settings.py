"""Discovery Settings endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class DiscoverySettingsAPI(BaseAPI):
    """Discovery Settings
    """

    def get_marketplace_brands(self, show_test_mode: bool, show_hidden: bool, network_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List discovery settings for brands

        Retrieve a list of brands and their campaign discovery settings

        ``GET /v2/networks/{networkId}/marketplace/settings/advertisers``

        Args:
            show_test_mode: [path ``show_test_mode``] Decide if campaigns should be returned if they are in test mode (default
                value: false)
            show_hidden: [path ``show_hidden``] Decide if campaigns should be returned if they are hidden (default value:
                false)
            network_id: [path ``networkId``]
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/marketplace/settings/advertisers'.format(show_test_mode=_q(show_test_mode), show_hidden=_q(show_hidden), network_id=_q(network_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def update_marketplace_brands(self, network_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update Brand Marketplace settings

        Update the discovery settings of the brand

        ``PUT /v2/networks/{networkId}/marketplace/settings/advertisers``

        Args:
            network_id: [path ``networkId``]
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/marketplace/settings/advertisers'.format(network_id=_q(network_id))
        query = {}
        hdrs = {}
        return self._client.request('PUT', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
