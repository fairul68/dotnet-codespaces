"""Brand Clicks endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class BrandClicksAPI(BaseAPI):
    """Brand Clicks
    """

    def brand_clicks(self, campaign_id: str, format: str, *, start_date: Optional[str] = None, end_date: Optional[str] = None, text_date: Optional[str] = None, timezone: Optional[str] = None, currency: Optional[Any] = None, date_type: Optional[str] = None, multipivot_pivot: Optional[str] = None, statuses: Optional[str] = None, offset: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve a Brand Clicks Report

        Return a mix of aggregated and basket/item level click data for a brand.

        ``GET /reporting/report_advertiser/campaign/{campaign_id}/click.{format}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            format: [path ``format``] (required) Format for the response
            start_date: [query ``start_date``] (required) Start date for data to be included in the report
            end_date: [query ``end_date``] End date for data to be included in the report
            text_date: [query ``text_date``] Restricts the results to one of the following - this hour, last hour, today,
                yesterday, this week, last week, last X days, this month, last month, this
                year, last year.
            timezone: [query ``timezone``] Enforce a specified Timezone.
            currency: [query ``currency[]``] Filter the results by the specified currency
            date_type: [query ``date_type``] This parameter to run the report for conversions that have been updated.
                When you specify `last_modified` or `approved_at` the response will only
                include conversions that were last modified or approved at in a date within
                the report date range.
            multipivot_pivot: [query ``multipivot[{pivot}][]``] Add a secondary pivot filter. You need to specify the pivot parameter name
                and the value to filter by. E.g. multipivot[publisher][]=111111l29.
                Supported values are: `publisher`, `product`, `advertiser_reference`.
            statuses: [query ``statuses[]``] Filter by statuses. Available values - approved, pending, rejected
            offset: [query ``offset``] Offset the results by a given amount. Defaults to 0.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/reporting/report_advertiser/campaign/{campaign_id}/click.{format}'.format(campaign_id=_q(campaign_id), format=_q(format))
        query = {'start_date': start_date, 'end_date': end_date, 'text_date': text_date, 'timezone': timezone, 'currency[]': currency, 'date_type': date_type, 'multipivot[{pivot}][]': multipivot_pivot, 'statuses[]': statuses, 'offset': offset}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
