"""Filter Sets endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class FilterSetsAPI(BaseAPI):
    """Filter Sets
    """

    def delete_campaign_group_saved_report(self, campaign_group_id: str, filter_set_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete a Campaign Group Saved Report

        ``DELETE /report/campaign_group/{campaign_group_id}/filter_sets/{filter_set_id}``

        Args:
            campaign_group_id: [path ``campaign_group_id``] (required) Id of the campaign group
            filter_set_id: [path ``filter_set_id``] (required) Id of the Saved Report
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/report/campaign_group/{campaign_group_id}/filter_sets/{filter_set_id}'.format(campaign_group_id=_q(campaign_group_id), filter_set_id=_q(filter_set_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
