"""Conversion Metrics endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class ConversionMetricsAPI(BaseAPI):
    """Conversion Metrics
    """

    def list_conversion_metrics(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Conversion Metrics

        List all available Conversion Metrics.

        ``GET /reference/conversion_metric``
        """
        path = '/reference/conversion_metric'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
