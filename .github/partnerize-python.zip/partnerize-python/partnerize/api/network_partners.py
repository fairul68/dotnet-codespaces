"""Network Partners endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class NetworkPartnersAPI(BaseAPI):
    """A Brand can view all Partners who are created on their network. This endpoint is not
    specific to a Campaign,
    therefore it pools all available Partners who have been created or are able to
    access their Network.   ​
    It is also possible to accept new Partners onto the Network, or to reject any
    approved or pending Partners
    from the Network. If a Partners is rejected from the Network, they will be
    automatically rejected from all participating Campaigns.
    """

    def create_network_partners(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create network partner

        Create partners on your network.

        ``POST /user/publisher``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/user/publisher'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def create_network_user_partners(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create network partner with user account

        Create partners on your network with their own Partnerize user account, allowing
        them to login directly to the Partnerize platform.

        ``POST /user``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/user'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def list_all_partners_on_the_network(self, network_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Partners on the Network

        View all Partners on the Network.

        ``GET /network/{network_id}/publisher``

        Args:
            network_id: [path ``network_id``] (required) ID of the network
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/network/{network_id}/publisher'.format(network_id=_q(network_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def update_partners_network_status(self, network_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update Partner's Network status

        Update the `network_status` of a Partner by passing each `publisher_id` along with
        the relevant `network_status` in an object within a `publishers` array.

        ``POST /network/{network_id}/publisher``

        Args:
            network_id: [path ``network_id``] (required) ID of the network
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/network/{network_id}/publisher'.format(network_id=_q(network_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
