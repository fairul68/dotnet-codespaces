"""Reporting on Meta data endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class ReportingOnMetaDataAPI(BaseAPI):
    """Reporting Meta is functionality that allows Brands to generate reports based on
    specific meta data.
    """

    def list_all_meta_reports_for_a_campaign(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Meta Reports for a Campaign

        ``GET /campaign/{campaign_id}/reporting/meta/reports``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/reporting/meta/reports'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_meta_report(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create a Meta Report for a Campaign

        ``POST /campaign/{campaign_id}/reporting/meta/reports``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/reporting/meta/reports'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def retrieve_meta_report(self, campaign_id: str, report_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve a Meta Report for a Campaign

        ``GET /campaign/{campaign_id}/reporting/meta/reports/{report_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            report_id: [path ``report_id``] (required) ID of the report
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/reporting/meta/reports/{report_id}'.format(campaign_id=_q(campaign_id), report_id=_q(report_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def delete_meta_report(self, campaign_id: str, report_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete a Meta Report for a Campaign

        ``DELETE /campaign/{campaign_id}/reporting/meta/reports/{report_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            report_id: [path ``report_id``] (required) ID of the report
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/reporting/meta/reports/{report_id}'.format(campaign_id=_q(campaign_id), report_id=_q(report_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def view_meta_report_results(self, campaign_id: str, report_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """View the results of a Meta Report for a Campaign.

        The endpoint allows you to retrieve the results of a specified Meta Report for a
        Campaign. The endpoint supports `.csv` format. Use
        `../campaign/{campaign_id}/reporting/meta/reports/{report_id}/results.csv` to export
        the results as a csv file.

        ``GET /campaign/{campaign_id}/reporting/meta/reports/{report_id}/results``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            report_id: [path ``report_id``] (required) ID of the report
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/reporting/meta/reports/{report_id}/results'.format(campaign_id=_q(campaign_id), report_id=_q(report_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def list_meta_values(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Meta Values for a Campaign

        ``GET /campaign/{campaign_id}/reporting/meta/values``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/reporting/meta/values'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def list_meta_whitelist_keys(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Meta Whitelist Keys for a Campaign

        ``GET /campaign/{campaign_id}/reporting/meta/whitelist``

        Args:
            campaign_id: [path ``campaign_id``]
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/reporting/meta/whitelist'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
