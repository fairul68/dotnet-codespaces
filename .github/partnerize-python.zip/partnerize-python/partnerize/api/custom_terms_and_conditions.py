"""Custom Terms and Conditions endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CustomTermsAndConditionsAPI(BaseAPI):
    """Manage partner specific terms and conditions. You can use this group of endpoints to
    create custom terms and conditions for certain partners.
    """

    def list_terms_and_conditions_for_a_given_campaign(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List All Custom Terms and Conditions for given campaign

        List All Custom Terms and Conditions for given campaign

        ``GET /campaign/{campaign_id}/custom_terms/``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/custom_terms/'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_custom_terms_and_conditions(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create Custom Terms and Conditions

        Creates Custom Terms and Conditions for a given campaign and associates them with
        the provided partners.

        ``POST /campaign/{campaign_id}/custom_terms/``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/custom_terms/'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def read_partner_campaign_custom_terms(self, campaign_id: str, publisher_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Partner's Terms and Conditions for a capaign.

        List Terms and Conditions for a Partner on the specified campaign.

        ``GET /campaign/{campaign_id}/custom_terms/publisher/{publisher_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            publisher_id: [path ``publisher_id``] (required) ID of the Partner
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/custom_terms/publisher/{publisher_id}'.format(campaign_id=_q(campaign_id), publisher_id=_q(publisher_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def delete_campaign_custom_terms(self, campaign_id: str, custom_terms_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete specific Custom Terms and Conditions

        Delete Campaign Terms and Conditions for a given campaign.

        ``DELETE /campaign/{campaign_id}/custom_terms/{custom_terms_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            custom_terms_id: [path ``custom_terms_id``] (required) Id of the Campaign Terms and Conditions to delete
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/custom_terms/{custom_terms_id}'.format(campaign_id=_q(campaign_id), custom_terms_id=_q(custom_terms_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_assoc_campaign_custom_terms(self, campaign_id: str, custom_terms_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Associate Custom Terms and Conditions with Partners

        Associate the Custom Terms and Conditions with a list of Partners.

        ``POST /campaign/{campaign_id}/custom_terms/custom_terms_id/association``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            custom_terms_id: [path ``custom_terms_id``] (required) ID of Campaign Terms and Conditions to associate with a list of Partners
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/custom_terms/custom_terms_id/association'.format(campaign_id=_q(campaign_id), custom_terms_id=_q(custom_terms_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_assoc_campaign_custom_terms(self, campaign_id: str, custom_terms_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Remove associations between the Custom Terms and Conditions and Partners

        Remove associations between the Custom Terms and Conditions and a list of Partners.
        If all associations are removed successfully a `200 OK` status code response is
        returned. In the cases where there were errors a `207 Multi-status` response is
        returned and the body of the response will contain the list of errors for the failed
        ones.

        ``DELETE /campaign/{campaign_id}/custom_terms/custom_terms_id/association``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            custom_terms_id: [path ``custom_terms_id``] (required) ID of Campaign Terms and Conditions to associate with a list of Partners
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/custom_terms/custom_terms_id/association'.format(campaign_id=_q(campaign_id), custom_terms_id=_q(custom_terms_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
