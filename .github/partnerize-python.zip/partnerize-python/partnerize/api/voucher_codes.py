"""Voucher Codes endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class VoucherCodesAPI(BaseAPI):
    """A Voucher references a coupon code, or voucher code which the Brand offers to their
    customers to usually perform a price discount at the end of the transaction.
    Specific rules can be set to defined Vouchers ensuring that only valid codes can be
    used and can also be restricted to specific Partners.
    """

    def list_all_voucher_codes(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Campaign Voucher Codes

        View all Voucher Codes associated with the Campaign.

        ``GET /campaign/{campaign_id}/voucher_code``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/voucher_code'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_voucher_codes(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create Voucher Codes

        Create new Vouchers by passing each Voucher object within a `voucher_codes` array. A
        `voucher_code` string to define
        the actual code must be passed with each object, and to allocate the Voucher to
        specific Groups, pass the Group ids
        in a `commission_groups` array.

        ``POST /campaign/{campaign_id}/voucher_code``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/voucher_code'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def update_voucher_codes(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update Voucher Codes

        Update Vouchers by referencing the `voucher_code_id` in each Group object within the
        `voucher_codes` array.

        ``PUT /campaign/{campaign_id}/voucher_code``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/voucher_code'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('PUT', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def retrieve_a_voucher_code(self, campaign_id: str, voucher_code_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve a Voucher Code

        Outputs the specified Voucher Code.

        ``GET /campaign/{campaign_id}/voucher_code/{voucher_code_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            voucher_code_id: [path ``voucher_code_id``] (required) ID of the voucher code
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/voucher_code/{voucher_code_id}'.format(campaign_id=_q(campaign_id), voucher_code_id=_q(voucher_code_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
