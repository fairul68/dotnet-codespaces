"""Conversion Types endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class ConversionTypesAPI(BaseAPI):
    """Conversion Types
    """

    def list_conversion_type(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Conversion Type

        List all the conversion types.

        ``GET /reference/conversion_type``
        """
        path = '/reference/conversion_type'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
