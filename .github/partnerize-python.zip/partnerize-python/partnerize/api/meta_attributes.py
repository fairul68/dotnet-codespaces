"""Meta Attributes endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class MetaAttributesAPI(BaseAPI):
    """Based on all tracked events, a real-time cache of currencies and non standard
    conversion and conversion item
    attributes are kept for all Campaigns and Partners. This endpoint can be used to
    determine what non standard
    data might appear in reports/exports and is also useful when building an external
    app which will display Conversion data.
    """

    def list_all_meta_attributes_for_campaign(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Meta attributes for Campaign

        View all unique Meta attributes for the Campaign.

        ``GET /campaign/{campaign_id}/meta``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/meta'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
