"""Network Terms and Conditions Acknowledgments (v3) endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class NetworkTermsAndConditionsAcknowledgmentsV3API(BaseAPI):
    """Network Terms and Conditions Acknowledgments (v3)
    """

    def create_network_terms_and_conditions_acknowledgment(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create network terms and conditions acknowledgment

        Create an acknowledgement for network terms and conditions

        ``POST /v3/brand/network-terms-and-conditions-acknowledgments``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/network-terms-and-conditions-acknowledgments'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
