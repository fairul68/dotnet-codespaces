"""Campaign Transaction Queries endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CampaignTransactionQueriesAPI(BaseAPI):
    """Transaction Queries (TQs) allow Partners to raise disputes about conversions with a
    Brand.
    There are three types of Transaction Queries:
    - Untracked: A conversion has not been tracked.
    - Incorrect Commission: A conversion does not have the correct Partner commission
    value.
    - Declined: The Brand has rejected a conversion.
    """

    def list_all_transaction_queries(self, campaign_id: str, *, body: Any = None, transaction_query_id: Optional[str] = None, transaction_query_type: Optional[str] = None, publisher_reference: Optional[str] = None, conversion_reference: Optional[str] = None, conversion_date_time: Optional[str] = None, current_state: Optional[str] = None, date_range_column: Optional[str] = None, date_range_start: Optional[str] = None, date_range_end: Optional[str] = None, text_date: Optional[str] = None, sort_column: Optional[str] = None, order_by: Optional[str] = None, tq_export: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Transaction Queries for a Campaign

        Return the details of all Transaction Queries created on a campaign.

        ``GET /campaign/{campaign_id}/tq``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            transaction_query_id: [query ``transaction_query_id``] Filter by the ID of a transaction query
            transaction_query_type: [query ``transaction_query_type``] Filter by the type
            publisher_reference: [query ``publisher_reference``] Filter by a partner reference
            conversion_reference: [query ``conversion_reference``] Filter by a conversion reference
            conversion_date_time: [query ``conversion_date_time``] Filter by a conversion date
            current_state: [query ``current_state``] Filter by the current state
            date_range_column: [query ``date_range_column``] Field to filter the date range on
            date_range_start: [query ``date_range_start``] Start of a date range
            date_range_end: [query ``date_range_end``] End of a date range
            text_date: [query ``text_date``] Natural language representation of a date range
            sort_column: [query ``sort_column``] Field to sort the results by
            order_by: [query ``order_by``] Direction to sort the results by
            tq_export: [query ``tq_export``] Download the results as a CSV file
            body: JSON request body (dict/list). Generate a CSV file in a job and send the result to this email address,
                helpful when processing takes too long for a normal download
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/tq'.format(campaign_id=_q(campaign_id))
        query = {'transaction_query_id': transaction_query_id, 'transaction_query_type': transaction_query_type, 'publisher_reference': publisher_reference, 'conversion_reference': conversion_reference, 'conversion_date_time': conversion_date_time, 'current_state': current_state, 'date_range_column': date_range_column, 'date_range_start': date_range_start, 'date_range_end': date_range_end, 'text_date': text_date, 'sort_column': sort_column, 'order_by': order_by, 'tq_export': tq_export}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def approve_a_transaction_query(self, campaign_id: str, transaction_query_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Approve a Transaction Query

        Approve a single Transaction Query. Only Transaction Queries with a status of
        pending can be approved.

        ``POST /campaign/{campaign_id}/tq/{transaction_query_id}/approve``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of a Campaign
            transaction_query_id: [path ``transaction_query_id``] (required) ID of the Transaction Query
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/tq/{transaction_query_id}/approve'.format(campaign_id=_q(campaign_id), transaction_query_id=_q(transaction_query_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def pend_a_transaction_query(self, campaign_id: str, transaction_query_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Pend a Transaction Query

        Pend a single Transaction Query. Only Transaction Queries with a status of rejected
        can be pended.

        ``POST /campaign/{campaign_id}/tq/{transaction_query_id}/pend``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of a Campaign
            transaction_query_id: [path ``transaction_query_id``] (required) ID of the Transaction Query
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/tq/{transaction_query_id}/pend'.format(campaign_id=_q(campaign_id), transaction_query_id=_q(transaction_query_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def reject_a_transaction_query(self, campaign_id: str, transaction_query_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Reject a Transaction Query

        Reject a single Transaction Query. Only Transaction Queries with a status of pending
        can be rejected.

        ``POST /campaign/{campaign_id}/tq/{transaction_query_id}/reject``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of a campaign
            transaction_query_id: [path ``transaction_query_id``] (required) ID of the transaction query
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/tq/{transaction_query_id}/reject'.format(campaign_id=_q(campaign_id), transaction_query_id=_q(transaction_query_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def bulk_process_transaction_queries(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Bulk processing of Transaction Queries

        Process multiple Transaction Queries in a single API call. The same rules as
        approving, rejecting and pending single Transaction Queries apply. The actions are
        processed asynchronously and the Job endpoint must be polled to find out when all
        have been completed.

        ``POST /campaign/{campaign_id}/tq/process``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of a Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/tq/process'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
