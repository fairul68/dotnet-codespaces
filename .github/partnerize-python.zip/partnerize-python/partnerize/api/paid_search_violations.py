"""Paid Search Violations endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class PaidSearchViolationsAPI(BaseAPI):
    """Paid Search Violations
    """

    def list_paid_search_violations(self, participation_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List paid search violations

        Get a timeline of paid search violations for a given participation

        ``GET /v3/brand/participations/{participationId}/paid_search_violation``

        Args:
            participation_id: [path ``participationId``] (required) The ID of the participation that the paid search violation is associated
                with
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/participations/{participation_id}/paid_search_violation'.format(participation_id=_q(participation_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_a_paid_search_violation(self, participation_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create a paid search violation

        Create a paid search violation time frame for a given participation

        ``POST /v3/brand/participations/{participationId}/paid_search_violation``

        Args:
            participation_id: [path ``participationId``] (required) The ID of the participation that the paid search violation will be applied
                to
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/participations/{participation_id}/paid_search_violation'.format(participation_id=_q(participation_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_a_paid_search_violation(self, participation_id: str, paid_search_violation_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete a paid search violation

        Deletes or ends a paid search violation. If a paid search violation has been started
        but the end date has not elapsed, then the end date will be updated to the current
        datetime. If the paid search violation has not been started then the paid search
        violation will be completely deleted.

        ``DELETE /v3/brand/participations/{participationId}/paid_search_violation/{paidSearchViolationId}``

        Args:
            participation_id: [path ``participationId``] (required) The ID of the participation that the paid search violation is associated
                with
            paid_search_violation_id: [path ``paidSearchViolationId``] (required) The ID of the paid search violation that will be deleted
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/participations/{participation_id}/paid_search_violation/{paid_search_violation_id}'.format(participation_id=_q(participation_id), paid_search_violation_id=_q(paid_search_violation_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
