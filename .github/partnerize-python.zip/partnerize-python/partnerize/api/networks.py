"""Networks endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class NetworksAPI(BaseAPI):
    """All API calls are contextual to the User that is making the request, and all User
    accounts are associated with the
    Network that they are created on. Each network has a unique `application_user_key`.
    """

    def list_networks(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Networks

        Retrieve the details of the authenticated Network.

        ``GET /network``
        """
        path = '/network'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
