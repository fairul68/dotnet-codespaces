"""Currency countries endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CurrencyCountriesAPI(BaseAPI):
    """Currency countries
    """

    def list_country_currency_combinations(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Country Currency Combinations

        List all Country Currency Combinations

        ``GET /reference/currency/country``
        """
        path = '/reference/currency/country'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
