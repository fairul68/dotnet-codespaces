"""User Contexts endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class UserContextsAPI(BaseAPI):
    """User Contexts
    """

    def list_all_user_contexts(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all User Contexts

        List all User Context types.

        ``GET /reference/user_context``
        """
        path = '/reference/user_context'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
