"""Verticals endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class VerticalsAPI(BaseAPI):
    """Verticals
    """

    def list_all_verticals(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Verticals

        Reference data endpoint which lists all the verticals.

        ``GET /reference/vertical``
        """
        path = '/reference/vertical'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
