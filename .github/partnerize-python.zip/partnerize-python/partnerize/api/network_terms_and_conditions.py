"""Network Terms and Conditions endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class NetworkTermsAndConditionsAPI(BaseAPI):
    """Terms and conditions endpoint that returns terms and conditions that must be
    accepted by a partner to join the network.
    """

    def list_network_terms_and_conditions(self, locale: Any, country: Any, network_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all terms and conditions for a network

        ``GET /reference/terms/{locale}/{country}/{network_id}``

        Args:
            locale: [path ``locale``] (required) Specified locale
            country: [path ``country``] (required) Specified ISO-2 country code
            network_id: [path ``network_id``] (required) ID of the network
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/reference/terms/{locale}/{country}/{network_id}'.format(locale=_q(locale), country=_q(country), network_id=_q(network_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
