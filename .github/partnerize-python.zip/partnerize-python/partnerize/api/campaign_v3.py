"""Campaign v3 endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CampaignV3API(BaseAPI):
    """Campaign v3
    """

    def list_campaigns(self, *, brand_id: Optional[str] = None, status: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List campaigns

        Return a list of campaigns of the logged-in user's brand

        ``GET /v3/brand/campaigns``

        Args:
            brand_id: [query ``brand_id``] Brand ID to filter campaigns by
            status: [query ``status``] Campaign status to filter by. When omitted, campaigns of all statuses are
                returned.
                Allowed values: `a`, `p`, `r`, `n`.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/campaigns'
        query = {'brand_id': brand_id, 'status': status}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_campaign(self, campaign_id: str, *, extra_info: Optional[str] = None, extra_fields: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get campaign

        Return information about a single campaign from the provided ID.

        ``GET /v3/brand/campaigns/{campaignId}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Partnerize campaign to be returned
            extra_info: [query ``extra_info``] Comma-separated list of extra_info to fetch; defaults to none; supply `*` to
                fetch all; unknown values will be ignored
            extra_fields: [query ``extra_fields``] Comma-separated list of additional fields to include in the response.
                Supported values are `vertical_id` and `reporting_timezone`.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/campaigns/{campaign_id}'.format(campaign_id=_q(campaign_id))
        query = {'extra_info': extra_info, 'extra_fields': extra_fields}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def partial_update_campaign(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Partial campaign update

        Update some information of a campaign.

        ``PATCH /v3/brand/campaigns/{campaignId}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Partnerize campaign to be returned
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/campaigns/{campaign_id}'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
