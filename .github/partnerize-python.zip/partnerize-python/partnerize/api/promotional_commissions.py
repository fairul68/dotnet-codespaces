"""Promotional Commissions endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class PromotionalCommissionsAPI(BaseAPI):
    """Promotional Commission Endpoints
    """

    def get_promotional_commissions(self, campaign_id: str, *, at: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Promotional Commissions

        This endpoint lists all active and scheduled promotional commissions for the given
        campaign.

        ``GET /v2/campaigns/{campaignId}/commissions/promotions``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the promotional commissions for
            at: [query ``at``] Check the promotional commissions for a given moment
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/promotions'.format(campaign_id=_q(campaign_id))
        query = {'at': at}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_promotional_commission(self, campaign_id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create Promotional Commission

        This creates a new promotional commission for the given campaign

        ``POST /v2/campaigns/{campaignId}/commissions/promotions``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to create the promotional commission for
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/promotions'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def get_promotional_commission(self, campaign_id: str, promotional_id: str, *, include: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get Promotional Commission

        This endpoint returns the promotional commission for the given campaign and
        promotional commission ID.

        ``GET /v2/campaigns/{campaignId}/commissions/promotions/{promotionalId}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign the promotional commission belongs to
            promotional_id: [path ``promotionalId``] (required) The ID of the promotional commission to retrieve
            include: [query ``include``] The historical edits will be shown under the history.data attribute when set
                to 'history'.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/promotions/{promotional_id}'.format(campaign_id=_q(campaign_id), promotional_id=_q(promotional_id))
        query = {'include': include}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def update_promotional_commission(self, campaign_id: str, promotional_id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Modify Promotional Commission

        Modifies the promotional commission for the given commission ID and campaign

        ``PATCH /v2/campaigns/{campaignId}/commissions/promotions/{promotionalId}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to update the promotional commission for
            promotional_id: [path ``promotionalId``] (required) The ID of the promotional commission to update
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/promotions/{promotional_id}'.format(campaign_id=_q(campaign_id), promotional_id=_q(promotional_id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_promotional_commission(self, campaign_id: str, promotional_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete Promotional Commission

        This endpoint deletes a given Promotional Commission

        ``DELETE /v2/campaigns/{campaignId}/commissions/promotions/{promotionalId}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign the promotional commission belongs to
            promotional_id: [path ``promotionalId``] (required) The ID of the promotional commission to delete
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/promotions/{promotional_id}'.format(campaign_id=_q(campaign_id), promotional_id=_q(promotional_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def retire_promotional_commission(self, campaign_id: str, promotional_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retire Promotional Commission

        This endpoint retires a given Promotional Commission

        ``POST /v2/campaigns/{campaignId}/commissions/promotions/{promotionalId}/retire``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign the promotional commission belongs to
            promotional_id: [path ``promotionalId``] (required) The ID of the promotional commission to retire
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/promotions/{promotional_id}/retire'.format(campaign_id=_q(campaign_id), promotional_id=_q(promotional_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
