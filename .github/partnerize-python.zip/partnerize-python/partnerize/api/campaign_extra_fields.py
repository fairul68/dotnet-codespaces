"""Campaign Extra Fields endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CampaignExtraFieldsAPI(BaseAPI):
    """Campaign Extra Fields
    """

    def list_all_campaign_extra_fields(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Campaign Extra Fields

        List all the types of campaign extra fields.

        ``GET /reference/campaign_extra_field``
        """
        path = '/reference/campaign_extra_field'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
