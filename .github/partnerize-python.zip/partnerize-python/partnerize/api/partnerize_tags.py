"""Partnerize Tags endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class PartnerizeTagsAPI(BaseAPI):
    """Partnerize Tags allow the creation, management and automated serving of various
    Partnerize features into websites.  All generated Partnerize Tags include a `url` of
    which can be embedded into websites to serve back the enabled features of that tag
    in JavaScript content.  Partnerize Tags only need to be integrated once, allowing
    features of the tag to be updated at any time using the Partnerize Tags APIs.  To
    view available features of the Partnerize Tag, use the [List Partnerize Tag
    Features](#operation/listPartnerizeTagFeatures) API.
    """

    def list_partnerize_tags(self, *, brand_id: Optional[str] = None, with_features: Optional[bool] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Partnerize Tags

        Return a list of available Partnerize Tags.

        ``GET /v3/brand/partnerize-tags``

        Args:
            brand_id: [query ``brand_id``] ID of the brand to restrict scope of Partnerize Tags to
            with_features: [query ``with_features``] Optional flag to include features as part of the response
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/partnerize-tags'
        query = {'brand_id': brand_id, 'with_features': with_features}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_partnerize_tag(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create Partnerize Tag

        Generates a new Partnerize Tag for the requested brand. Freshly generated tag will
        be empty, without any features enabled by default.  To allow for global propagation,
        tags will typically be available for use 15 minutes after their generation.

        ``POST /v3/brand/partnerize-tags``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/partnerize-tags'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def get_partnerize_tag(self, partnerize_tag_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get Partnerize Tag

        Return information about a single Partnerize Tag from the provided ID.

        ``GET /v3/brand/partnerize-tags/{partnerizeTagId}``

        Args:
            partnerize_tag_id: [path ``partnerizeTagId``] (required) The ID of the Partnerize Tag to be returned
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/partnerize-tags/{partnerize_tag_id}'.format(partnerize_tag_id=_q(partnerize_tag_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def update_partnerize_tag(self, partnerize_tag_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update Partnerize Tag

        Updates a specific Partnerize Tag.

        ``PATCH /v3/brand/partnerize-tags/{partnerizeTagId}``

        Args:
            partnerize_tag_id: [path ``partnerizeTagId``] (required) The ID of the Partnerize Tag to be updated
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/partnerize-tags/{partnerize_tag_id}'.format(partnerize_tag_id=_q(partnerize_tag_id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_partnerize_tag(self, partnerize_tag_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete Partnerize Tag

        Deletes a specific Partnerize Tag.

        ``DELETE /v3/brand/partnerize-tags/{partnerizeTagId}``

        Args:
            partnerize_tag_id: [path ``partnerizeTagId``] (required) The ID of the Partnerize Tag to be deleted
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/partnerize-tags/{partnerize_tag_id}'.format(partnerize_tag_id=_q(partnerize_tag_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
