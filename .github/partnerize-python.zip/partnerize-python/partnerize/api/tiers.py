"""Tiers endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class TiersAPI(BaseAPI):
    """Commission Tiers Endpoints
    """

    def get_commission_tiers(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Commission Tiers

        This endpoint lists all upcoming and currently active commission tiers for the given
        campaign.

        ``GET /v2/campaigns/{campaignId}/commissions/tiers``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the commission tiers for
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/tiers'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_commission_tier(self, campaign_id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create Commission Tier

        This creates a new commission tier for the given campaign

        ``POST /v2/campaigns/{campaignId}/commissions/tiers``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to create the commission tier for
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/tiers'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def update_commission_tier(self, campaign_id: str, tier_id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Modify Commission Tier

        Modifies the commission tier for the given tier ID and campaign

        ``PATCH /v2/campaigns/{campaignId}/commissions/tiers/{tierId}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to update the commission tier for
            tier_id: [path ``tierId``] (required) The ID of the tier to update
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/tiers/{tier_id}'.format(campaign_id=_q(campaign_id), tier_id=_q(tier_id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_commission_tier(self, campaign_id: str, tier_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete Commission Tier

        This endpoint deletes a given Commission Tier

        ``DELETE /v2/campaigns/{campaignId}/commissions/tiers/{tierId}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the commission tiers for
            tier_id: [path ``tierId``] (required) The ID of the commission tier to delete
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/tiers/{tier_id}'.format(campaign_id=_q(campaign_id), tier_id=_q(tier_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
