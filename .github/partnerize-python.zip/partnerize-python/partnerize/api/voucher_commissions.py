"""Voucher Commissions endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class VoucherCommissionsAPI(BaseAPI):
    """Voucher Commission Endpoints
    """

    def get_voucher_commissions(self, campaign_id: str, *, at: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Voucher Commissions

        This endpoint lists all active and scheduled Voucher commissions for the given
        campaign.

        ``GET /campaign/{campaignId}/optimisation/voucher/commission``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the Voucher commissions for
            at: [query ``at``] Check the Voucher commissions for a given moment
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/optimisation/voucher/commission'.format(campaign_id=_q(campaign_id))
        query = {'at': at}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def post_voucher_commission(self, campaign_id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create Voucher Commission

        This endpoint saves a given Voucher Commission

        ``POST /campaign/{campaignId}/optimisation/voucher/commission``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign the voucher commission belongs to
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/optimisation/voucher/commission'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def get_voucher_commission(self, campaign_id: str, commission_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Show Voucher Commissions

        This endpoint shows an active or scheduled Voucher commission for the given
        campaign.

        ``GET /campaign/{campaignId}/optimisation/voucher/commission/{commissionId}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the Voucher commissions for
            commission_id: [path ``commissionId``] (required) The ID of the commission to edit the Voucher commissions for
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/optimisation/voucher/commission/{commission_id}'.format(campaign_id=_q(campaign_id), commission_id=_q(commission_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_voucher_commissions_put(self, campaign_id: str, commission_id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Edit Voucher Commissions

        This endpoint edits all active and scheduled Voucher commission for the given
        campaign.

        ``PUT /campaign/{campaignId}/optimisation/voucher/commission/{commissionId}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the Voucher commissions for
            commission_id: [path ``commissionId``] (required) The ID of the commission to edit the Voucher commissions for
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/optimisation/voucher/commission/{commission_id}'.format(campaign_id=_q(campaign_id), commission_id=_q(commission_id))
        query = {}
        hdrs = {}
        return self._client.request('PUT', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_voucher_commission(self, campaign_id: str, commission_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete Scheduled Voucher Commission

        This endpoint deletes a scheduled Voucher Commission. Active Voucher Commissions
        should be retired.

        ``DELETE /campaign/{campaignId}/optimisation/voucher/commission/{commissionId}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign the voucher commission belongs to
            commission_id: [path ``commissionId``] (required) The ID of the commission to retire the Voucher commissions for
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/optimisation/voucher/commission/{commission_id}'.format(campaign_id=_q(campaign_id), commission_id=_q(commission_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def retire_voucher_commission(self, campaign_id: str, commission_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retire Active Voucher Commission

        This endpoint retires an active Voucher Commission. Scheduled Voucher Commissions
        should be deleted.

        ``POST /campaign/{campaignId}/optimisation/voucher/commission/{commissionId}/retire``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign the voucher commission belongs to
            commission_id: [path ``commissionId``] (required) The ID of the commission to retire the Voucher commissions for
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/optimisation/voucher/commission/{commission_id}/retire'.format(campaign_id=_q(campaign_id), commission_id=_q(commission_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
