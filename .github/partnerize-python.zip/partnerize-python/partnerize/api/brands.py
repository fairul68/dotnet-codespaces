"""Brands endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class BrandsAPI(BaseAPI):
    """A User can create one or more Brand accounts. A User can also have access to one or
    more Brand accounts -
    this is determined by the User's permissions. A Network admin may choose to grant a
    User access to multiple
    entities within their Network.
    """

    def list_all_brands(self, *, limit: Optional[float] = None, offset: Optional[float] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Brands

        One or more Brands can reside on a Network. This endpoint will output a listing of
        all Brands who reside on
        the Network and the output is contextual based on the permissions of the User making
        the request to the endpoint.
        A limited Brand schema will be utilised for any Brand that the User does not have
        appropriate permissions to view.

        ``GET /user/advertiser``

        Args:
            limit: [query ``limit``]
            offset: [query ``offset``]
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/user/advertiser'
        query = {'limit': limit, 'offset': offset}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_brand_account(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create Brand

        Create a new Brand account attached to the authenticated User.

        ``POST /user/advertiser``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/user/advertiser'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def retrieve_a_brand(self, advertiser_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve a Brand

        Outputs the specified brand.

        ``GET /user/advertiser/{advertiser_id}``

        Args:
            advertiser_id: [path ``advertiser_id``] (required) ID of the brand
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/user/advertiser/{advertiser_id}'.format(advertiser_id=_q(advertiser_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def update_a_brand(self, advertiser_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update a Brand

        Update the specified Brand.

        ``POST /user/advertiser/{advertiser_id}``

        Args:
            advertiser_id: [path ``advertiser_id``] (required) ID of the brand
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/user/advertiser/{advertiser_id}'.format(advertiser_id=_q(advertiser_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def get_brands_for_a_network(self, network_id: str, *, with_: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get brands for a network

        Lists brands for a given network

        ``GET /v3/network/{networkId}/brands``

        Args:
            network_id: [path ``networkId``] Network ID to get brands for
            with_: [query ``with``] Extra data to fetch as a comma seperated list. Currently only accepts
                "deeplink-domains"
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/network/{network_id}/brands'.format(network_id=_q(network_id))
        query = {'with': with_}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_brands_for_a_user(self, *, network_id: Optional[str] = None, with_: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get brands for a user

        Lists brands the user has access to

        ``GET /v3/brand``

        Args:
            network_id: [query ``network_id``] A way to filter brands by network
            with_: [query ``with``] Extra data to fetch as a comma seperated list. Currently only accepts
                "deeplink-domains"
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand'
        query = {'network_id': network_id, 'with': with_}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
