"""Incidents endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class IncidentsAPI(BaseAPI):
    """Incidents
    """

    def get_incidents(self, campaign_id: str, *, partner_id: Optional[str] = None, ip_address: Optional[str] = None, metric: Optional[str] = None, type: Optional[str] = None, status: Optional[str] = None, start_date: Optional[str] = None, end_date: Optional[str] = None, cursor_id: Optional[str] = None, limit: Optional[int] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Incidents

        Get all incidents that are not dismissed ordered by date descending

        ``GET /v2/campaigns/{campaign_id}/fraud/incidents``

        Args:
            campaign_id: [path ``campaign_id``] (required) Campaign ID
            partner_id: [query ``partner_id``] Partner ID to filter
            ip_address: [query ``ip_address``] IP address to filter
            metric: [query ``metric``] Filter the query by incident `metric`. This parameter must be used in
                conjunction with `type`.
            type: [query ``type``] Filter the query by incident `type`. This parameter must be used in
                conjunction with `metric`.
            status: [query ``status``] Filter the query by incident `status`.
            start_date: [query ``start_date``] Only include incidents after this date.
            end_date: [query ``end_date``] Only include incidents before this date.
            cursor_id: [query ``cursor_id``] Cursor used for pagination.
            limit: [query ``limit``] Limit the number of incidents returned.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/fraud/incidents'.format(campaign_id=_q(campaign_id))
        query = {'partner_id': partner_id, 'ip_address': ip_address, 'metric': metric, 'type': type, 'status': status, 'start_date': start_date, 'end_date': end_date, 'cursor_id': cursor_id, 'limit': limit}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_incident(self, campaign_id: str, incident_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get Incident

        Get a specific incident

        ``GET /v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) Campaign ID
            incident_id: [path ``incident_id``] (required) Incident ID
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}'.format(campaign_id=_q(campaign_id), incident_id=_q(incident_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def delete_incident(self, campaign_id: str, incident_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete Incident

        Delete a specific incident

        ``DELETE /v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) Campaign ID
            incident_id: [path ``incident_id``] (required) Incident ID
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}'.format(campaign_id=_q(campaign_id), incident_id=_q(incident_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_incidents_aggregation(self, campaign_id: str, *, start_date: Optional[str] = None, end_date: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get Incidents Aggregation

        Get an aggregated total of incidents by day

        ``GET /v2/campaigns/{campaign_id}/fraud/incidents-aggregation``

        Args:
            campaign_id: [path ``campaign_id``] (required) Campaign ID
            start_date: [query ``start_date``] (required) Only include incidents after this date.
            end_date: [query ``end_date``] (required) Only include incidents before this date.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/fraud/incidents-aggregation'.format(campaign_id=_q(campaign_id))
        query = {'start_date': start_date, 'end_date': end_date}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def fraud_reject_partner(self, campaign_id: str, incident_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Reject Partner

        Reject a Partner due to fraudulent claims. This means that the partner will no
        longer be valid for this Campaign

        ``POST /v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}/reject-partner``

        Args:
            campaign_id: [path ``campaign_id``] (required) Campaign ID
            incident_id: [path ``incident_id``] (required) Incident ID
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}/reject-partner'.format(campaign_id=_q(campaign_id), incident_id=_q(incident_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def fraud_reject_conversions(self, campaign_id: str, incident_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Reject Fraudulent Conversions

        Reject fraudulent conversions for the Incident

        ``POST /v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}/reject-conversions``

        Args:
            campaign_id: [path ``campaign_id``] (required) Campaign ID
            incident_id: [path ``incident_id``] (required) Incident ID
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}/reject-conversions'.format(campaign_id=_q(campaign_id), incident_id=_q(incident_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def fraud_pend_conversions(self, campaign_id: str, incident_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Set Incident Conversion status to Pending

        Set Incident Conversion status to Pending

        ``POST /v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}/pend-conversions``

        Args:
            campaign_id: [path ``campaign_id``] (required) Campaign ID
            incident_id: [path ``incident_id``] (required) Incident ID
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}/pend-conversions'.format(campaign_id=_q(campaign_id), incident_id=_q(incident_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_incident_partners(self, campaign_id: str, *, metric: Optional[str] = None, type: Optional[str] = None, status: Optional[str] = None, start_date: Optional[str] = None, end_date: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Incident-partners

        Get a list of all partners that are associated with incidents.

        ``GET /v2/campaigns/{campaign_id}/fraud/incident-partners``

        Args:
            campaign_id: [path ``campaign_id``] (required) Campaign ID
            metric: [query ``metric``] Filter the query by incident `metric`. This parameter must be used in
                conjunction with `type`.
            type: [query ``type``] Filter the query by incident `type`. This parameter must be used in
                conjunction with `metric`.
            status: [query ``status``] Filter the query by incident `status`.
            start_date: [query ``start_date``] Only consider incidents after this date.
            end_date: [query ``end_date``] Only consider incidents before this date.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/fraud/incident-partners'.format(campaign_id=_q(campaign_id))
        query = {'metric': metric, 'type': type, 'status': status, 'start_date': start_date, 'end_date': end_date}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
