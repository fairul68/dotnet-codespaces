"""Transaction Query Reasons endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class TransactionQueryReasonsAPI(BaseAPI):
    """Transaction Query Reasons
    """

    def list_transaction_query_reasons(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Transaction Query Reasons for a Campaign

        Return the details of all saved Transaction Query Reasons.

        ``GET /campaign/{campaign_id}/tq_reasons``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of a Campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/tq_reasons'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_a_transaction_query_reason(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create a Transaction Query Reason for a Campaign

        Create a new saved Transaction Query reason.

        ``POST /campaign/{campaign_id}/tq_reasons``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of a Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/tq_reasons'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_a_transaction_query_reason(self, campaign_id: str, transaction_query_reason_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete a Transaction Query Reason for a Campaign

        Delete a saved Transaction Query Reason for a Campaign.

        ``POST /campaign/{campaign_id}/tq_reasons/{transaction_query_reason_id}/delete``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of a Campaign
            transaction_query_reason_id: [path ``transaction_query_reason_id``] (required) ID of the Transaction Query Reason
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/tq_reasons/{transaction_query_reason_id}/delete'.format(campaign_id=_q(campaign_id), transaction_query_reason_id=_q(transaction_query_reason_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
