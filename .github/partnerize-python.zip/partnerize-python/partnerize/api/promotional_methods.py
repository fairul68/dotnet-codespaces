"""Promotional Methods endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class PromotionalMethodsAPI(BaseAPI):
    """Promotional Methods
    """

    def list_all_promotional_method(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Promotional Method

        List all the types of payment methods.

        ``GET /reference/promotional_method``
        """
        path = '/reference/promotional_method'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
