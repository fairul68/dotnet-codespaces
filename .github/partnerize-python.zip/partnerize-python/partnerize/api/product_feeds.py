"""Product Feeds endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class ProductFeedsAPI(BaseAPI):
    """A Brand may want to offer a selection of Product Feeds to their Partners on a
    specific Campaign.
    When a Product Feed is created, it will be periodically downloaded and parsed for
    all Partners who participate on the Campaign to ensure their tracking links are
    inserted for all anchor links within the Product Feed.
    Any text based file format is supported.
    """

    def list_all_product_feeds(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Product Feeds for a Campaign

        Return the details of all Product Feeds associated with a Campaign.

        ``GET /campaign/{campaign_id}/feed``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/feed'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_a_product_feed_for_a_campaign(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create a Product Feed

        Create one or more Product Feeds against the Campaign entity. Each Product Feed is
        sent as an array within a top level `feeds` array.

        ``POST /campaign/{campaign_id}/feed``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/feed'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def update_a_campaign_feed(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update a Product Feed for a Campaign

        Update one or more `feeds` against the Campaign entity. Each Product Feed is sent as
        an array within a top level `feeds` array and must contain its associated `feed_id`
        or `location`. As `location` is a unique identifier, it's not possible to change the
        location of a feed once created. To update the location, first update the feed and
        set `active: n`, then create a new feed with the new location.

        ``PUT /campaign/{campaign_id}/feed``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/feed'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('PUT', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
