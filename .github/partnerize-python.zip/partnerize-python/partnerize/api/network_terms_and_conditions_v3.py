"""Network Terms and Conditions (v3) endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class NetworkTermsAndConditionsV3API(BaseAPI):
    """Network Terms and Conditions (v3)
    """

    def list_network_terms_and_conditions(self, *, network_id: Optional[str] = None, types: Optional[Any] = None, locale: Optional[Any] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List network terms and conditions

        Lists all network terms and conditions that must be accepted by a brand

        ``GET /v3/brand/network-terms-and-conditions``

        Args:
            network_id: [query ``network_id``] (required) Filter by a network
            types: [query ``types``] Filter by terms and conditions types
            locale: [query ``locale``] Filter by locale.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/network-terms-and-conditions'
        query = {'network_id': network_id, 'types': types, 'locale': locale}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
