"""Jobs (v1) endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class JobsV1API(BaseAPI):
    """Jobs (v1)
    """

    def get_job_v1(self, job_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get a single job (v1)

        Returns information about a single v1 job by the given ID.

        Once the `job` `status` is `complete` the job output can be retrieved from the path
        given in the `hypermedia` `response` (`/job/111111l11/response.csv` in the response
        samples).

        ``GET /job/{jobID}``

        Args:
            job_id: [path ``jobID``] (required) Id of the job
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/job/{job_id}'.format(job_id=_q(job_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
