"""Campaigns endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CampaignsAPI(BaseAPI):
    """A Campaign is owned by a Brand and a Brand may have multiple Campaigns. A Campaign
    represents an entity which the Brand uses to represent something that they wish to
    allow Partners the chance to promote. A Campaign dictates what
    products/events/conversions can be promoted, and lets the Partners understand what
    Commission they would earn for generating sales/events/conversions. The Brand has
    complete control over their Campaigns and dictates which Partners they accept onto
    the Campaign to promote their services.
    """

    def list_all_campaigns(self, *, network_id: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Campaigns

        Return the details of all Campaigns attached to the Network account and visible to
        the authenticated User.
        The output is contextual based on the permissions of the User making the request to
        the endpoint. A limited Campaign
        schema will be utilised for any Campaign that the User does not have appropriate
        permissions to view.

        ``GET /campaign``

        Args:
            network_id: [query ``network_id``] ID of the network
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign'
        query = {'network_id': network_id}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_a_campaign(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create a Campaign

        To create a new Campaign, the Brand must pass their associated `advertiser_id`.

        ``POST /campaign``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def retrieve_a_campaign(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve a Campaign

        Outputs the specified Campaign.

        ``GET /campaign/{campaign_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def delete_a_campaign(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete a Campaign

        To delete a specific campaign, you must pass 3 required parameters:

        1. `'action' => 'delete'`

        2. `'campaign_id' => ''`

        3. `'retire_reason' => 'some excuse'`.

        ``POST /campaign/{campaign_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def update_a_campaign(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update a Campaign

        Update the specified Campaign.

        ``PUT /campaign/{campaign_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('PUT', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def list_all_brand_campaigns(self, advertiser_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Brand Campaigns

        This endpoint will output a listing of all Campaigns that reside under the provided
        Brand on the Network and the output is contextual based on the permissions of the
        User making the request to the endpoint.
        A limited Campaign schema will be utilised for any Campaign that the User does not
        have appropriate permissions to view.

        ``GET /user/advertiser/{advertiser_id}/campaign``

        Args:
            advertiser_id: [path ``advertiser_id``] (required) ID of the brand
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/user/advertiser/{advertiser_id}/campaign'.format(advertiser_id=_q(advertiser_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
