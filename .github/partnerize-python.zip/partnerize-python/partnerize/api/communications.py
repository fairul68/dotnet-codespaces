"""Communications endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CommunicationsAPI(BaseAPI):
    """Communications
    """

    def get_communications(self, *, status: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List communications

        Lists all communications which the user has access to. Filtering by status is
        available via a query parameter.

        ``GET /v2/communications``

        Args:
            status: [query ``status``] A comma separated list of statuses
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communications'
        query = {'status': status}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_communication(self, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Creates a new draft communication

        Draft communications belong to the user that created them (the owner).
        Note: this endpoint accepts publisher_ids or recipients, not both together

        ``POST /v2/communications``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communications'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def get_communication(self, id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieves a single communication

        Retrieves a communication for a given id

        ``GET /v2/communications/{id}``

        Args:
            id: [path ``id``] (required) The ID of the communication
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communications/{id}'.format(id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def update_communication(self, id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Updates a draft communication

        Only the owner of the draft can update it. The recipients of the communication can
        be defined by a list of emails or by a list of existing partner ids

        ``PUT /v2/communications/{id}``

        Args:
            id: [path ``id``] (required) The ID of the communication
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communications/{id}'.format(id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('PUT', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_communication(self, id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Deletes an existing draft communication

        Only the owner of the draft can delete it.

        ``DELETE /v2/communications/{id}``

        Args:
            id: [path ``id``] (required) The ID of the communication to be deleted
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communications/{id}'.format(id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_communication_content(self, id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Returns the content of a communication

        Returns the HTML content of an existing communication.

        ``GET /v2/communications/{id}/content``

        Args:
            id: [path ``id``] (required) The ID of the communication
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communications/{id}/content'.format(id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def update_communication_content(self, id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Updates the content of a communication

        Updates the HTML content of an existing communication.

        ``PUT /v2/communications/{id}/content``

        Args:
            id: [path ``id``] (required) The ID of the communication
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communications/{id}/content'.format(id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('PUT', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def send_communication_preview(self, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Sends a communication preview

        Send a preview of a communication

        ``POST /v2/communications/send-preview``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communications/send-preview'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def send_communication(self, id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Sends or schedules a draft communication

        Send a Communication

        ``POST /v2/communications/{id}/send``

        Args:
            id: [path ``id``] (required) The ID of the communication
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communications/{id}/send'.format(id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def cancel_communication(self, id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Cancels a scheduled communication

        Cancels the scheduling of a previously scheduled communication. This will change the
        communication status to draft.

        ``DELETE /v2/communications/{id}/cancel``

        Args:
            id: [path ``id``] (required) The ID of the communication to be cancelled
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communications/{id}/cancel'.format(id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_communicatons_report(self, *, limit: Optional[int] = None, offset: Optional[int] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Communications summary report

        Retrieves summary report for all sent communications.

        ``GET /v2/communications/summary``

        Args:
            limit: [query ``limit``] The number of records to retrieve
            offset: [query ``offset``] Starting position
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communications/summary'
        query = {'limit': limit, 'offset': offset}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
