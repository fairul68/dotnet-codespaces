"""Invoices endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class InvoicesAPI(BaseAPI):
    """So that Brands can receive payment for all approved conversion events they have
    generated across a Brand's Campaigns, the Brand must raise an Invoice and send
    payment to Partnerize. Once the payment has cleared, all funds will be deposited
    into the relevant Partner accounts.
    """

    def list_all_invoices(self, advertiser_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Invoices

        View all Invoices that have been created.

        ``GET /user/advertiser/{advertiser_id}/invoice``

        Args:
            advertiser_id: [path ``advertiser_id``] (required) ID of the Brand
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/user/advertiser/{advertiser_id}/invoice'.format(advertiser_id=_q(advertiser_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def retrieve_an_invoice(self, advertiser_id: str, invoice_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve an Invoice

        View an individual Invoice.

        ``GET /user/advertiser/{advertiser_id}/invoice/{invoice_id}``

        Args:
            advertiser_id: [path ``advertiser_id``] (required) ID of the Brand
            invoice_id: [path ``invoice_id``] (required) ID of the Invoice
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/user/advertiser/{advertiser_id}/invoice/{invoice_id}'.format(advertiser_id=_q(advertiser_id), invoice_id=_q(invoice_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
