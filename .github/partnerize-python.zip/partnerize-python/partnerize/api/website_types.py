"""Website Types endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class WebsiteTypesAPI(BaseAPI):
    """Website Types
    """

    def list_website_types(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Website Types

        List all the website types.

        ``GET /reference/website_type``
        """
        path = '/reference/website_type'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
