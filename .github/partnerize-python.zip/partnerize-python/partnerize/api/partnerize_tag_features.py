"""Partnerize Tag Features endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class PartnerizeTagFeaturesAPI(BaseAPI):
    """Partnerize Tag features are what power the Partnerize Tag, delivering Partnerize
    functionality to websites through the Partnerize Tag.  Partnerize Tag Features come
    in all shapes and sizes depending on the intended use case.  To find out more about
    Partnerize Tag Features and how they can be used, head over to the [Partnerize Help
    Hub](https://help.phgsupport.com/hc/en-us).
    """

    def list_partnerize_tag_features(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Available Partnerize Tag Features

        Returns a list of available features ready for enablement in a Partnerize Tag.

        ``GET /v3/brand/partnerize-tags/features``
        """
        path = '/v3/brand/partnerize-tags/features'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def list_partnerize_tag_enabled_features(self, tag_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Partnerize Tag Enabled Features

        Return a list of features enabled for a specific Partnerize Tag.

        ``GET /v3/brand/partnerize-tags/{tagId}/features``

        Args:
            tag_id: [path ``tagId``] (required) The ID of the Partnerize Tag
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/partnerize-tags/{tag_id}/features'.format(tag_id=_q(tag_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def enable_partnerize_tag_feature(self, tag_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Enable Feature on Partnerize Tag

        Enables a feature for a specific Partnerize Tag.

        ``POST /v3/brand/partnerize-tags/{tagId}/features``

        Args:
            tag_id: [path ``tagId``] (required) The ID of the Partnerize Tag
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/partnerize-tags/{tag_id}/features'.format(tag_id=_q(tag_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def disable_partnerize_tag_feature(self, tag_id: str, feature_name: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Disable Feature on Partnerize Tag

        Disables a feature for a specific Partnerize Tag.

        ``DELETE /v3/brand/partnerize-tags/{tagId}/features/{featureName}``

        Args:
            tag_id: [path ``tagId``] (required) The ID of the Partnerize Tag
            feature_name: [path ``featureName``] (required) The name of the feature to remove
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/brand/partnerize-tags/{tag_id}/features/{feature_name}'.format(tag_id=_q(tag_id), feature_name=_q(feature_name))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
