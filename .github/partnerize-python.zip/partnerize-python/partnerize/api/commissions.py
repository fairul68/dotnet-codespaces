"""Commissions endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CommissionsAPI(BaseAPI):
    """Commissions
    """

    def get_commissions(self, campaign_id: str, *, at: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Commissions

        This endpoint lists all upcoming and currently active standard commissions

        ``GET /v2/campaigns/{campaignId}/commissions``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the commissions for
            at: [query ``at``] The date and time to show active commissions for. If not set defaults to
                now.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions'.format(campaign_id=_q(campaign_id))
        query = {'at': at}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_commission(self, campaign_id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create Commission

        This endpoint creates a new commission

        ``POST /v2/campaigns/{campaignId}/commissions``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign to list the commissions for
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def get_commission(self, campaign_id: str, commission_id: str, *, include: Optional[str] = None, at: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get Commission

        Get the given commission

        ``GET /v2/campaigns/{campaignId}/commissions/{commissionId}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign the commission belongs to
            commission_id: [path ``commissionId``] (required) The ID of the commission to retrieve
            include: [query ``include``] The historical edits will be shown under the history.data attribute when set
                to 'history'.
                The endpoint will also return v1 Commissions when set to 'v1'"
            at: [query ``at``] The date and time to show active commissions for. If not set defaults to
                now.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/{commission_id}'.format(campaign_id=_q(campaign_id), commission_id=_q(commission_id))
        query = {'include': include, 'at': at}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def update_commission(self, campaign_id: str, commission_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update Commission

        Update the given commission. If it is currently active it will be retired and a new
        commission will be set up
        with the updated configuration.

        ``PATCH /v2/campaigns/{campaignId}/commissions/{commissionId}``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign the commission belongs to
            commission_id: [path ``commissionId``] (required) The ID of the commission to retrieve
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/{commission_id}'.format(campaign_id=_q(campaign_id), commission_id=_q(commission_id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def migrate_commission(self, campaign_id: str, commission_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Migrate Commission

        This endpoint migrates a given V1 Commission to a V2 Commission

        ``POST /v2/campaigns/{campaignId}/commissions/{commissionId}/migrate``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign the commission belongs to
            commission_id: [path ``commissionId``] (required) The ID of the commission to migrate
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/{commission_id}/migrate'.format(campaign_id=_q(campaign_id), commission_id=_q(commission_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def retire_commission(self, campaign_id: str, commission_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retire Commission

        This endpoint retires a given Commission.

        ``POST /v2/campaigns/{campaignId}/commissions/{commissionId}/retire``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign the commission belongs to
            commission_id: [path ``commissionId``] (required) The ID of the commission to retire
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/{commission_id}/retire'.format(campaign_id=_q(campaign_id), commission_id=_q(commission_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
