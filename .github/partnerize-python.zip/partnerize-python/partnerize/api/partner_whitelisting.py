"""Partner Whitelisting endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class PartnerWhitelistingAPI(BaseAPI):
    """Partner Whitelisting
    """

    def get_whitelisted_partners(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get Whitelisted Partners

        Retrieve all whitelisted partners

        ``GET /v2/campaigns/{campaign_id}/fraud/whitelisted-partners``

        Args:
            campaign_id: [path ``campaign_id``] (required) Campaign ID
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/fraud/whitelisted-partners'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def fraud_whitelist_partner(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Whitelist Partner

        Whitelist a trusted Partner.

        ``POST /v2/campaigns/{campaign_id}/fraud/whitelisted-partners``

        Args:
            campaign_id: [path ``campaign_id``] (required) Campaign ID
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/fraud/whitelisted-partners'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_whitelisted_partner(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Remove Partner from Whitelist

        Remove a partner from the whitelist

        ``DELETE /v2/campaigns/{campaign_id}/fraud/whitelisted-partners``

        Args:
            campaign_id: [path ``campaign_id``] (required) Campaign ID
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/fraud/whitelisted-partners'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
