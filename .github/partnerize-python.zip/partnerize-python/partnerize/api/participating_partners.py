"""Participating Partners endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class ParticipatingPartnersAPI(BaseAPI):
    """Before Partners can generate conversions for a Campaign, they must be approved to do
    so. A Partner can apply to
    be part of a Campaign, or the Brand can choose to add the Partner(s) of their choice
    to their own Campaign.
    Furthermore, if a Brand has stipulated their own unique set of Campaign Terms and
    Conditions, the Partner
    must explicitly agree to these if they are to be fully approved on the Campaign.
    """

    def list_all_participating_partners(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Participating Partners

        View all Partners Participating on the Campaign.

        ``GET /campaign/{campaign_id}/publisher``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/publisher'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def update_partner_participation(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update a Partner Participation on a Campaign

        Add new Campaign participations by passing each `publisher_id` along with the
        relevant `campaign_status` in an
        object within a `publishers` array.

        ``POST /campaign/{campaign_id}/publisher``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/publisher'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def retrieve_a_participating_partner(self, campaign_id: str, publisher_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve a Participating Partner

        View a specific Participating Partner.

        ``GET /campaign/{campaign_id}/publisher/{publisher_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            publisher_id: [path ``publisher_id``] (required) ID of the Partner
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/publisher/{publisher_id}'.format(campaign_id=_q(campaign_id), publisher_id=_q(publisher_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
