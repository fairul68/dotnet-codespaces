"""Partnership Models endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class PartnershipModelsAPI(BaseAPI):
    """Partnership Models
    """

    def list_partnership_models(self, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Partnership Models

        List all available partnership models.

        ``GET /reference/partnership_model``
        """
        path = '/reference/partnership_model'
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
