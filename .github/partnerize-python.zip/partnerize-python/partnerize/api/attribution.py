"""Attribution endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class AttributionAPI(BaseAPI):
    """Note: Attribution is a limited availability BETA feature.
    Attribution features allow you to control who the transaction is attributed to,
    based on the the configured rules. To process attribution rules we analyse clicks
    within the click trail going back the length of the cookie period for the campaign.
    """

    def get_partners_attribution(self, campaign_id: str, partner_id: str, campaign_id_: str, publisher_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Partner Attributions

        Get available ongoing and upcoming attribution opportunities for the given partner.

        Any of the keys within the response will be excluded if they are not applicable,
        such as not being enabled or configured for the partner.

        ``GET /v2/campaigns/{campaignId}/publishers/{publisherId}/attribution``

        Args:
            campaign_id: [path ``campaign_id``] (required) The ID of the campaign
            partner_id: [path ``partner_id``] (required) The ID of the partner
            campaign_id_: [path ``campaignId``]
            publisher_id: [path ``publisherId``]
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id_}/publishers/{publisher_id}/attribution'.format(campaign_id=_q(campaign_id), partner_id=_q(partner_id), campaign_id_=_q(campaign_id_), publisher_id=_q(publisher_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def get_v2_attribution(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Attribution Settings

        Get the status of each of the Attribution Settings

        ``GET /v2/campaigns/{campaignId}/attribution``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def post_v2_attribution(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update Attribution Settings

        Update the Attribution Settings

        ``PATCH /v2/campaigns/{campaignId}/attribution``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            body: JSON request body (dict/list).
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
