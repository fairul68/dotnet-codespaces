"""Split endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class SplitAPI(BaseAPI):
    """Split all CPA commissions between the initiator (first click), contributors
    (supporting click) and convertor (last click) in the click chain.
    """

    def get_v2_campaigns_campaign_id_attribution_split(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Split Settings

        Get the Split attribution settings for the given Campaign

        ``GET /v2/campaigns/{campaignId}/attribution/split``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/split'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def patch_v2_campaigns_campaign_id_attribution_split(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update Split Settings

        Update the Split settings for the given Campaign

        ``PATCH /v2/campaigns/{campaignId}/attribution/split``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/attribution/split'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
