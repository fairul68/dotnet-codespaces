"""Exports endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class ExportsAPI(BaseAPI):
    """Depending on the query parameters, an export request may need to be processed
    asynchronously. When that happens a background job will be automatically created,
    and the API response will describe the job rather than the export (see [Jobs
    v1](#operation/get_job_v1)).

    If the `complete_email` parameter has been set the export will be sent to the given
    address once the background job is complete.
    """

    def export_clicks(self, *, campaign_id: Optional[str] = None, publisher_id: Optional[str] = None, start_date: Optional[str] = None, end_date: Optional[str] = None, timezone: Optional[str] = None, complete_email: Optional[str] = None, limit: Optional[str] = None, export_reference: Optional[str] = None, encoding: Optional[str] = None, delimiter: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Export a Clicks Report

        Request a CSV for a granular Click report for the defined Campaign or Partner and
        within the requested time period.

        ``GET /reporting/export/export/click.csv``

        Args:
            campaign_id: [query ``campaign_id``] (required) ID of the campaign. You must provide either this parameter or
                `publisher_id`.
            publisher_id: [query ``publisher_id``] (required) ID of the partner. You must provide either this parameter or `campaign_id`
            start_date: [query ``start_date``] (required) Start date for data to be included in the report
            end_date: [query ``end_date``] (required) End date for data to be included in the report
            timezone: [query ``timezone``] Force a specified Timezone
            complete_email: [query ``complete_email``] When used in conjunction with limit=0 send a link to the CSV when generation
                is complete
            limit: [query ``limit``] When set to zero, attempt to download everything
            export_reference: [query ``export_reference``] Add a prefix to the report filename
            encoding: [query ``encoding``] + `UTF-8` - Default encoding

                + `UTF-16`
            delimiter: [query ``delimiter``] Choose the delimiter for separating values

                + comma

                + tab

                + pipe
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/reporting/export/export/click.csv'
        query = {'campaign_id': campaign_id, 'publisher_id': publisher_id, 'start_date': start_date, 'end_date': end_date, 'timezone': timezone, 'complete_email': complete_email, 'limit': limit, 'export_reference': export_reference, 'encoding': encoding, 'delimiter': delimiter}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def export_conversions(self, *, campaign_id: Optional[str] = None, publisher_id: Optional[str] = None, start_date: Optional[str] = None, end_date: Optional[str] = None, date_type: Optional[str] = None, currency: Optional[str] = None, conversion_id: Optional[str] = None, conversion_reference: Optional[str] = None, ref_conversion_metric_id: Optional[str] = None, timezone: Optional[str] = None, complete_email: Optional[str] = None, limit: Optional[str] = None, export_reference: Optional[str] = None, encoding: Optional[str] = None, delimiter: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Export Conversions Report

        Request a CSV for a granular Conversion report for the defined Campaign or Partner
        and within the requested time period. This report will give you details of orders at
        the basket level

        ``GET /reporting/export/export/conversion.csv``

        Args:
            campaign_id: [query ``campaign_id``] (required) ID of the campaign. You must provide either this parameter or
                `publisher_id`.
            publisher_id: [query ``publisher_id``] (required) ID of the partner. You must provide either this parameter or `campaign_id`.
            start_date: [query ``start_date``] (required) Start date for data to be included in the report
            end_date: [query ``end_date``] (required) End date for data to be included in the report
            date_type: [query ``date_type``] Alter the context of what the dates ranges apply to

                + standard - The default selection, range is based on conversion_time

                + approved_at - Alternative date range, which is based on the approved time
                of conversion items
            currency: [query ``currency[]``] Filter on a specific currency
            conversion_id: [query ``conversion_id``] Filter on a specific conversion_id
            conversion_reference: [query ``conversion_reference``] Filter on a specific conversion_reference value
            ref_conversion_metric_id: [query ``ref_conversion_metric_id``] Filter on a specific conversion metric, use an array for multiple
            timezone: [query ``timezone``] Force a specified Timezone
            complete_email: [query ``complete_email``] When used in conjunction with limit=0 send a link to the CSV when generation
                is complete
            limit: [query ``limit``] When set to zero, attempt to download everything
            export_reference: [query ``export_reference``] Add a prefix to the report filename
            encoding: [query ``encoding``] + `UTF-8` - Default encoding

                + `UTF-16`
            delimiter: [query ``delimiter``] Choose the delimiter for separating values

                + comma

                + tab

                + pipe
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/reporting/export/export/conversion.csv'
        query = {'campaign_id': campaign_id, 'publisher_id': publisher_id, 'start_date': start_date, 'end_date': end_date, 'date_type': date_type, 'currency[]': currency, 'conversion_id': conversion_id, 'conversion_reference': conversion_reference, 'ref_conversion_metric_id': ref_conversion_metric_id, 'timezone': timezone, 'complete_email': complete_email, 'limit': limit, 'export_reference': export_reference, 'encoding': encoding, 'delimiter': delimiter}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def export_conversion_items(self, *, campaign_id: Optional[str] = None, publisher_id: Optional[str] = None, start_date: Optional[str] = None, end_date: Optional[str] = None, date_type: Optional[str] = None, currency: Optional[str] = None, conversion_id: Optional[str] = None, conversion_reference: Optional[str] = None, ref_conversion_metric_id: Optional[str] = None, timezone: Optional[str] = None, include_payment_info: Optional[bool] = None, complete_email: Optional[str] = None, limit: Optional[str] = None, export_reference: Optional[str] = None, encoding: Optional[str] = None, delimiter: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Export Conversion Items Report

        Request a CSV for a granular Conversion report which includes all individual items
        for the defined Campaign or Partner and within the requested time period. In
        Conversion Item reports you will be able to see details of each item including
        individual item’s commission and value as each item will be listed on its own row
        within the report.

        ``GET /reporting/export/export/conversion_item.csv``

        Args:
            campaign_id: [query ``campaign_id``] (required) ID of the campaign. You must provide either this parameter or
                `publisher_id`.
            publisher_id: [query ``publisher_id``] (required) ID of the partner. You must provide either this parameter or `campaign_id`
            start_date: [query ``start_date``] (required) Start date for data to be included in the report
            end_date: [query ``end_date``] (required) End date for data to be included in the report
            date_type: [query ``date_type``] Alter the context of what the dates ranges apply to

                + standard - The default selection, range is based on conversion_time

                + approved_at - Alternative date range, which is based on the approved time
                of conversion items
            currency: [query ``currency[]``] Filter on a specific currency
            conversion_id: [query ``conversion_id``] Filter on a specific conversion_id
            conversion_reference: [query ``conversion_reference``] Filter on a specific conversion_reference value
            ref_conversion_metric_id: [query ``ref_conversion_metric_id``] Filter on a specific conversion metric, use an array for multiple
            timezone: [query ``timezone``] Force a specified Timezone
            include_payment_info: [query ``include_payment_info``] Include payment information. Omit parameter or false to exclude, which is
                the default. Fields included are:
                + payment_status
                + invoice_create_date
                + invoice_paid_date
            complete_email: [query ``complete_email``] When used in conjunction with limit=0 send a link to the CSV when generation
                is complete
            limit: [query ``limit``] When set to zero, attempt to download everything
            export_reference: [query ``export_reference``] Add a prefix to the report filename
            encoding: [query ``encoding``] + `UTF-8` - Default encoding

                + `UTF-16`
            delimiter: [query ``delimiter``] Choose the delimiter for separating values

                + comma

                + tab

                + pipe
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/reporting/export/export/conversion_item.csv'
        query = {'campaign_id': campaign_id, 'publisher_id': publisher_id, 'start_date': start_date, 'end_date': end_date, 'date_type': date_type, 'currency[]': currency, 'conversion_id': conversion_id, 'conversion_reference': conversion_reference, 'ref_conversion_metric_id': ref_conversion_metric_id, 'timezone': timezone, 'include_payment_info': include_payment_info, 'complete_email': complete_email, 'limit': limit, 'export_reference': export_reference, 'encoding': encoding, 'delimiter': delimiter}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
