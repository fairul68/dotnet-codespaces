"""Communication Templates endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CommunicationTemplatesAPI(BaseAPI):
    """Communication Templates
    """

    def list_communication_template(self, *, name: Optional[str] = None, source: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get a list of communication templates

        ``GET /v2/communication-templates``

        Args:
            name: [query ``name``] Name of template to search by
            source: [query ``source``] Source of the template to filter by
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communication-templates'
        query = {'name': name, 'source': source}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_communication_template(self, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Creates a new communication template

        ``POST /v2/communication-templates``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communication-templates'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def read_communication_template(self, id: str, *, source: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get a single communication template

        ``GET /v2/communication-templates/{id}``

        Args:
            id: [path ``id``] (required) ID of the template to get
            source: [query ``source``] (required) Whether the template is from Partnerize or Unlayer
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communication-templates/{id}'.format(id=_q(id))
        query = {'source': source}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def patch_communication_template(self, id: str, body: Any, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Updates a communication template

        ``PATCH /v2/communication-templates/{id}``

        Args:
            id: [path ``id``] (required) ID of the template to patch
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communication-templates/{id}'.format(id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_communication_template(self, id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete a single communication template

        ``DELETE /v2/communication-templates/{id}``

        Args:
            id: [path ``id``] (required) ID of the Partnerize template to delete
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communication-templates/{id}'.format(id=_q(id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def fetch_communication_template_thumbnail(self, id: str, *, source: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Get a single communication template's thumbnail

        ``GET /v2/communication-templates/{id}/thumbnail``

        Args:
            id: [path ``id``] (required) ID of the template to get
            source: [query ``source``] (required) Whether the thumbnail is for a Partnerize or Unlayer template
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/communication-templates/{id}/thumbnail'.format(id=_q(id))
        query = {'source': source}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
