"""Saved Reports endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class SavedReportsAPI(BaseAPI):
    """Manage sets of filters for reporting. Those can be saved for either a single
    campaign or a campaign group.
    """

    def retrieve_campaign_group_saved_report(self, campaign_group_id: str, filter_set_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve a Campaign Group Saved Report

        Retrieve a Campaign Group Saved Report by id

        ``GET /report/campaign_group/{campaign_group_id}/filter_sets/{filter_set_id}``

        Args:
            campaign_group_id: [path ``campaign_group_id``] (required) Id of the campaign group
            filter_set_id: [path ``filter_set_id``] (required) Id of the Saved Report
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/report/campaign_group/{campaign_group_id}/filter_sets/{filter_set_id}'.format(campaign_group_id=_q(campaign_group_id), filter_set_id=_q(filter_set_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def update_campaign_group_saved_report(self, campaign_group_id: str, filter_set_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update a Campaign Group Saved Report

        Update a Campaign Group Saved Report by id

        ``PUT /report/campaign_group/{campaign_group_id}/filter_sets/{filter_set_id}``

        Args:
            campaign_group_id: [path ``campaign_group_id``] (required) Id of the campaign group
            filter_set_id: [path ``filter_set_id``] (required) Id of the Saved Report
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/report/campaign_group/{campaign_group_id}/filter_sets/{filter_set_id}'.format(campaign_group_id=_q(campaign_group_id), filter_set_id=_q(filter_set_id))
        query = {}
        hdrs = {}
        return self._client.request('PUT', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
