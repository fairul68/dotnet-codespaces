"""Commission Groups endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CommissionGroupsAPI(BaseAPI):
    """Commission Groups
    """

    def list_commission_groups(self, network_id: str, *, network_id_: Optional[str] = None, active: Optional[Any] = None, has_participation: Optional[bool] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List commission groups

        Lists all network commission groups

        ``GET /v3/network/{networkId}/commission-groups``

        Args:
            network_id: [path ``networkId``]
            network_id_: [query ``network_id``] (required) Filter by a network
            active: [query ``active``] Whether the commission groups are still ongoing
            has_participation: [query ``has_participation``] Only return commission groups that have partners participating
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v3/network/{network_id}/commission-groups'.format(network_id=_q(network_id))
        query = {'network_id': network_id_, 'active': active, 'has_participation': has_participation}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
