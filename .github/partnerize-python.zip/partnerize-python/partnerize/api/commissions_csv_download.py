"""Commissions CSV Download endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CommissionsCSVDownloadAPI(BaseAPI):
    """Commissions CSV Download
    """

    def get_commission_csv_download(self, campaign_id: str, *, start_date_time: Optional[str] = None, end_date_time: Optional[str] = None, type: Optional[str] = None, status: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """CSV Download.

        Request a CSV for a Commission report which includes all individual items defined
        for the Campaign. Each item represents a commission type of default, standard,
        promotional or voucher commission and rates.

        ``GET /v2/campaigns/{campaignId}/commissions/all.csv``

        Args:
            campaign_id: [path ``campaignId``] (required) The ID of the campaign for the commissions
            start_date_time: [query ``start_date_time``] Limits list to commissions active at/from this date
            end_date_time: [query ``end_date_time``] Limits list to commissions active until this date
            type: [query ``type``] Limits list to commissions of specified types
            status: [query ``status``] Limits list to commissions with specified status
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/campaigns/{campaign_id}/commissions/all.csv'.format(campaign_id=_q(campaign_id))
        query = {'start_date_time': start_date_time, 'end_date_time': end_date_time, 'type': type, 'status': status}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
