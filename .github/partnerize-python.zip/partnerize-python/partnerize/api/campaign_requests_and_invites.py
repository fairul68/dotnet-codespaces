"""Campaign Requests and Invites endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class CampaignRequestsAndInvitesAPI(BaseAPI):
    """Campaign Requests and Invites
    """

    def partner_requests_invites(self, network_id: str, *, vertical_id: Optional[str] = None, promo_method_id: Optional[str] = None, operating_country: Optional[str] = None, promotional_country: Optional[str] = None, campaign_id: Optional[str] = None, status: Optional[str] = None, search: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Partner Campaign Requests and Invites

        Lists partners with campaign requests or invites

        ``GET /v2/networks/{networkId}/campaign-requests-invites``

        Args:
            network_id: [path ``networkId``] (required) ID of the brand network
            vertical_id: [query ``vertical_id``] ID of the vertical being filtered by
            promo_method_id: [query ``promo_method_id``] ID of the promo method being filtered by
            operating_country: [query ``operating_country``] The operating country code being filtered by
            promotional_country: [query ``promotional_country``] The promotional country ISO code
            campaign_id: [query ``campaign_id``] ID of the vertical being filtered by
            status: [query ``status``] The status of the interaction
            search: [query ``search``] Query string being search for which gets checked against the applicable
                fields.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/campaign-requests-invites'.format(network_id=_q(network_id))
        query = {'vertical_id': vertical_id, 'promo_method_id': promo_method_id, 'operating_country': operating_country, 'promotional_country': promotional_country, 'campaign_id': campaign_id, 'status': status, 'search': search}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def partner_requests_invites_filters(self, network_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List Campaign Requests and Invites Filters.

        Lists filters which can be used in conjuction with the List Campaign Requests and
        Invites contains the values required for the campaign interaction page filters.

        ``GET /v2/networks/{networkId}/campaign-requests-invites/filters``

        Args:
            network_id: [path ``networkId``] (required) ID of the brand network
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/campaign-requests-invites/filters'.format(network_id=_q(network_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def partner_requests_invites_detail(self, network_id: str, publisher_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve Partner Campaign Invites and Requests Details.

        Retrieve details for campaign invites and requests of a particular partner.

        ``GET /v2/networks/{networkId}/campaign-requests-invites/partners/{publisherId}``

        Args:
            network_id: [path ``networkId``] (required) ID of the brand network
            publisher_id: [path ``publisherId``] (required) The ID of the partner
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/campaign-requests-invites/partners/{publisher_id}'.format(network_id=_q(network_id), publisher_id=_q(publisher_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def accept_campaign_requests(self, network_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Accept Campaign Requests

        This endpont is now `Obsolete`. Use [Approve and Invite Partners to
        Campaigns](#tag/Campaign-Requests-and-Invites/operation/post-v2-networks-network_id-
        invite-network-partners) instead
        An Advertiser may accept requests from Partners to join campaigns within their
        Network. This bulk endpoint allows a user to reject multiple requests in one call.
        The payload contains one or more campaign ID and partner ID pairs that uniquely
        identify each campaign request to accept.

        ``POST /v2/networks/{networkId}/campaign-requests/accept``

        Args:
            network_id: [path ``networkId``] (required) ID of the network
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/campaign-requests/accept'.format(network_id=_q(network_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def decline_campaign_requests(self, network_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Decline Campaign Requests

        An Advertiser may decline requests from Partners to join campaigns within their
        Network. This bulk endpoint allows a user to decline multiple requests in one call.
        The payload contains one or more campaign ID and partner ID pairs that uniquely
        identify each campaign request to decline. Each partner and campaign pair must
        include a decline "reason". Use null if no reason is provided.

        ``POST /v2/networks/{networkId}/campaign-requests/decline``

        Args:
            network_id: [path ``networkId``] (required) ID of the network
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/campaign-requests/decline'.format(network_id=_q(network_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def invite_dry_run(self, network_id: Any, *, partner_collection_id: Optional[str] = None, campaign_ids: Optional[list] = None, search: Optional[str] = None, limit: Optional[float] = None, offset: Optional[float] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Display pending outcomes - invitations and approvals

        List all potential invitations and approvals for given set of campaigns

        ``GET /v2/networks/{network_id}/invite/network-partners``

        Args:
            network_id: [path ``network_id``] (required) The network id
            partner_collection_id: [query ``partner_collection_id``] (required)
            campaign_ids: [query ``campaign_ids``] (required)
            search: [query ``search``]
            limit: [query ``limit``]
            offset: [query ``offset``]
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/invite/network-partners'.format(network_id=_q(network_id))
        query = {'partner_collection_id': partner_collection_id, 'campaign_ids': campaign_ids, 'search': search, 'limit': limit, 'offset': offset}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def post_v2_networks_network_id_invite_network_partners(self, network_id: str, *, body: Any = None, x_prefer: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Approve and Invite Partners to Campaigns

        An Advertiser can invite one or more Network Partners to one or more Campaigns. The
        user must have manage participation permission over each campaign in the payload.
        The payload will be validated and invitations will be created only if all fields are
        valid. If a partner has already been invited or is approved on the campaign, the
        campaign will be skipped. If the partner has an existing request to join the
        campaign, the request will be resolved and the partner will be immediately approved
        on the campaign. Notifications will be sent according to each partner's preferences.

        ``POST /v2/networks/{network_id}/invite/network-partners``

        Args:
            network_id: [path ``network_id``] (required)
            x_prefer: [header ``X-Prefer``]
            body: JSON request body (dict/list). Selection based requests simply require a list of Publisher and Campaign
                IDs. The server will create invitations from the combination of the two
                lists.

                Collection based requests require a partner collection creating first.

                Alternatively when inviting many Publishers at once, instead of listing
                every PublisherID, a filter based request allows the user to specify filters
                with which to match Publishers. You can exclude specific Publishers by
                listing their IDs using the `excluded_publisher_id` property.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/invite/network-partners'.format(network_id=_q(network_id))
        query = {}
        hdrs = {'X-Prefer': x_prefer}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def export_dry_run(self, network_id: Any, *, partner_collection_id: Optional[str] = None, campaign_ids: Optional[list] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Export pending outcomes - invitations and approvals into CSV

        CSV all potential invitations and approvals for given set of campaigns

        ``POST /v2/networks/{network_id}/invite/network-partners.csv``

        Args:
            network_id: [path ``network_id``] (required) The network id
            partner_collection_id: [query ``partner_collection_id``] (required)
            campaign_ids: [query ``campaign_ids``] (required)
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/invite/network-partners.csv'.format(network_id=_q(network_id))
        query = {'partner_collection_id': partner_collection_id, 'campaign_ids': campaign_ids}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def post_v2_networks_network_id_reject_partners(self, network_id: str, *, body: Any = None, x_prefer: Optional[str] = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Reject partners from a campaign

        An Advertiser can reject one or more Partners from a campaign.

        ``POST /v2/networks/{network_id}/reject/network-partners``

        Args:
            network_id: [path ``network_id``] (required)
            x_prefer: [header ``X-Prefer``]
            body: JSON request body (dict/list). Selection based requests simply require a list of Publisher IDs. The server
                will approve publishers in the list.

                Collection based requests require a partner collection creating first.

                Alternatively when blocking many Publishers at once, instead of listing
                every PublisherID, a filter based request allows the user to specify filters
                with which to match Publishers. You can exclude specific Publishers by
                listing their IDs using the `excluded_publisher_id` property.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/v2/networks/{network_id}/reject/network-partners'.format(network_id=_q(network_id))
        query = {}
        hdrs = {'X-Prefer': x_prefer}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
