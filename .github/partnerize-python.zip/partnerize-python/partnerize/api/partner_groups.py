"""Partner Groups endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class PartnerGroupsAPI(BaseAPI):
    """A Campaign owner can organise Partners into Partner Groups, also known as Commission
    Groups. These Groups can be used for Reporting purposes, Commission offers and
    Voucher Code allocation.
    """

    def list_partner_groups(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Partner (Commission) Groups for a given campaign

        View all Partner (Commission) Groups for a campaign with all associated partners.

        ``GET /campaign/{campaign_id}/commission_group``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/commission_group'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def retrieve_a_partner_group(self, campaign_id: str, commission_group_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve a Partner (Commission) Group

        Retrieves the specified Partner (Commission) Group.

        ``GET /campaign/{campaign_id}/commission_group/{commission_group_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the campaign
            commission_group_id: [path ``commission_group_id``] (required) ID of the Partner (Commission) group
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/commission_group/{commission_group_id}'.format(campaign_id=_q(campaign_id), commission_group_id=_q(commission_group_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_partner_groups(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create Partner (Commission) Groups

        Create new Partner (Commission) Groups. To add Partners into the Partner
        (Commission) Group pass them in a `publishers` array.

        ``POST /commission_group``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/commission_group'
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def update_partner_commission_groups(self, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update Partner (Commission) Groups

        Update Partner (Commission) Groups by referencing the `commission_group_id` in each
        Group object within the `commission_groups` array.

        ``PUT /commission_group``

        Args:
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/commission_group'
        query = {}
        hdrs = {}
        return self._client.request('PUT', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)
