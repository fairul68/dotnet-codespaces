"""Deals endpoints (generated from the Partnerize OpenAPI spec)."""
from typing import Any, Dict, Optional

from .._base import BaseAPI, _q


class DealsAPI(BaseAPI):
    """A Brand may want to offer a specific Deal to Partners on a specific Campaign. These
    Deals represent a timed promotion which can be programmatically ingested into the
    Partner's platform and offered dynamically to their user base.
    """

    def list_all_campaign_deals(self, campaign_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """List all Campaign Deals

        Return the details of all Deals associated to the Campaign.

        ``GET /campaign/{campaign_id}/deal``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/deal'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def create_a_campaign_deal(self, campaign_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Create a Campaign Deal

        Create a new Deal against the Campaign entity.

        ``POST /campaign/{campaign_id}/deal``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/deal'.format(campaign_id=_q(campaign_id))
        query = {}
        hdrs = {}
        return self._client.request('POST', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def retrieve_a_campaign_deal(self, campaign_id: str, deal_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Retrieve a Campaign Deal

        Review the specified Deal.

        ``GET /campaign/{campaign_id}/deal/{deal_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            deal_id: [path ``deal_id``] (required) ID of the Deal
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/deal/{deal_id}'.format(campaign_id=_q(campaign_id), deal_id=_q(deal_id))
        query = {}
        hdrs = {}
        return self._client.request('GET', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)

    def update_a_campaign_deal(self, campaign_id: str, deal_id: str, *, body: Any = None, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Update a Campaign Deal

        Update properties of the specified Deal.

        ``PATCH /campaign/{campaign_id}/deal/{deal_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            deal_id: [path ``deal_id``] (required) ID of the Deal
            body: JSON request body (dict/list). JSON request body.
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/deal/{deal_id}'.format(campaign_id=_q(campaign_id), deal_id=_q(deal_id))
        query = {}
        hdrs = {}
        return self._client.request('PATCH', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=body, raw=raw)

    def delete_a_campaign(self, campaign_id: str, deal_id: str, *, params: Optional[Dict[str, Any]] = None, headers: Optional[Dict[str, str]] = None, raw: bool = False) -> Any:
        """Delete a Campaign

        Delete a Deal, which is the same as updating the Deal by setting `active` to `n`.

        ``DELETE /campaign/{campaign_id}/deal/{deal_id}``

        Args:
            campaign_id: [path ``campaign_id``] (required) ID of the Campaign
            deal_id: [path ``deal_id``] (required) ID of the deal
            params: Extra query parameters merged into the request.
            headers: Extra HTTP headers.
            raw: Return the ``requests.Response`` instead of the decoded body.
        """
        path = '/campaign/{campaign_id}/deal/{deal_id}'.format(campaign_id=_q(campaign_id), deal_id=_q(deal_id))
        query = {}
        hdrs = {}
        return self._client.request('DELETE', path, query=query, headers=hdrs, extra_params=params, extra_headers=headers, json=None, raw=raw)
