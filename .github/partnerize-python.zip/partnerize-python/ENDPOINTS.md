# Endpoint reference

Generated from *Partnerize Brands API* v1.4.99. 250 operations in 78 groups.

## Attribution — `client.attribution`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_partners_attribution()` | GET | `/v2/campaigns/{campaignId}/publishers/{publisherId}/attribution` | Partner Attributions |
| `get_v2_attribution()` | GET | `/v2/campaigns/{campaignId}/attribution` | List Attribution Settings |
| `post_v2_attribution()` | PATCH | `/v2/campaigns/{campaignId}/attribution` | Update Attribution Settings |

## Brand Clicks — `client.brand_clicks`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `brand_clicks()` | GET | `/reporting/report_advertiser/campaign/{campaign_id}/click.{format}` | Retrieve a Brand Clicks Report |

## Brand Conversions — `client.brand_conversions`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `brand_conversions()` | GET | `/reporting/report_advertiser/campaign/{campaign_id}/conversion.{format}` | Retrieve a Brand Conversions Report |

## Brands — `client.brands`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_brands()` | GET | `/user/advertiser` | List all Brands |
| `create_brand_account()` | POST | `/user/advertiser` | Create Brand |
| `retrieve_a_brand()` | GET | `/user/advertiser/{advertiser_id}` | Retrieve a Brand |
| `update_a_brand()` | POST | `/user/advertiser/{advertiser_id}` | Update a Brand |
| `get_brands_for_a_network()` | GET | `/v3/network/{networkId}/brands` | Get brands for a network |
| `get_brands_for_a_user()` | GET | `/v3/brand` | Get brands for a user |

## Campaign Conversions — `client.campaign_conversions`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `v3_conversion_bulk_update()` | POST | `/v3/brand/campaigns/{campaignID}/conversions/bulk` | Bulk update of conversions |

## Campaign Extra Fields — `client.campaign_extra_fields`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_campaign_extra_fields()` | GET | `/reference/campaign_extra_field` | List all Campaign Extra Fields |

## Campaign Group Campaigns — `client.campaign_group_campaigns`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `retrieve_a_list_of_campaigns_in_a_campaign_group()` | GET | `/v3/brand/campaign-groups/{campaign_group_id}/campaigns` | Retrieve a List of Campaigns in a Campaign Group |

## Campaign Requests and Invites — `client.campaign_requests_and_invites`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `partner_requests_invites()` | GET | `/v2/networks/{networkId}/campaign-requests-invites` | List Partner Campaign Requests and Invites |
| `partner_requests_invites_filters()` | GET | `/v2/networks/{networkId}/campaign-requests-invites/filters` | List Campaign Requests and Invites Filters. |
| `partner_requests_invites_detail()` | GET | `/v2/networks/{networkId}/campaign-requests-invites/partners/{publisherId}` | Retrieve Partner Campaign Invites and Requests Details. |
| `accept_campaign_requests()` | POST | `/v2/networks/{networkId}/campaign-requests/accept` | Accept Campaign Requests |
| `decline_campaign_requests()` | POST | `/v2/networks/{networkId}/campaign-requests/decline` | Decline Campaign Requests |
| `invite_dry_run()` | GET | `/v2/networks/{network_id}/invite/network-partners` | Display pending outcomes - invitations and approvals |
| `post_v2_networks_network_id_invite_network_partners()` | POST | `/v2/networks/{network_id}/invite/network-partners` | Approve and Invite Partners to Campaigns |
| `export_dry_run()` | POST | `/v2/networks/{network_id}/invite/network-partners.csv` | Export pending outcomes - invitations and approvals into CSV |
| `post_v2_networks_network_id_reject_partners()` | POST | `/v2/networks/{network_id}/reject/network-partners` | Reject partners from a campaign |

## Campaign Terms and Conditions — `client.campaign_terms_and_conditions`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `read_custom_terms()` | GET | `/campaign/{campaign_id}/custom_terms/{terms_id}?{download=true}` | Retrieve Campaign Terms and Conditions |

## Campaign Transaction Queries — `client.campaign_transaction_queries`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_transaction_queries()` | GET | `/campaign/{campaign_id}/tq` | List all Transaction Queries for a Campaign |
| `approve_a_transaction_query()` | POST | `/campaign/{campaign_id}/tq/{transaction_query_id}/approve` | Approve a Transaction Query |
| `pend_a_transaction_query()` | POST | `/campaign/{campaign_id}/tq/{transaction_query_id}/pend` | Pend a Transaction Query |
| `reject_a_transaction_query()` | POST | `/campaign/{campaign_id}/tq/{transaction_query_id}/reject` | Reject a Transaction Query |
| `bulk_process_transaction_queries()` | POST | `/campaign/{campaign_id}/tq/process` | Bulk processing of Transaction Queries |

## Campaign v3 — `client.campaign_v3`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_campaigns()` | GET | `/v3/brand/campaigns` | List campaigns |
| `get_campaign()` | GET | `/v3/brand/campaigns/{campaignId}` | Get campaign |
| `partial_update_campaign()` | PATCH | `/v3/brand/campaigns/{campaignId}` | Partial campaign update |

## Campaigns — `client.campaigns`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_campaigns()` | GET | `/campaign` | List all Campaigns |
| `create_a_campaign()` | POST | `/campaign` | Create a Campaign |
| `retrieve_a_campaign()` | GET | `/campaign/{campaign_id}` | Retrieve a Campaign |
| `delete_a_campaign()` | POST | `/campaign/{campaign_id}` | Delete a Campaign |
| `update_a_campaign()` | PUT | `/campaign/{campaign_id}` | Update a Campaign |
| `list_all_brand_campaigns()` | GET | `/user/advertiser/{advertiser_id}/campaign` | List all Brand Campaigns |

## Clicks — `client.clicks`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `post_clicks_count()` | POST | `/v3/brand/analytics/clicks/count` | Count |
| `post_clicks_explode()` | POST | `/v3/brand/analytics/clicks/explode` | Explode |
| `post_clicks_filter()` | POST | `/v3/brand/analytics/clicks/filter` | Filter |
| `post_clicks_timeseries()` | POST | `/v3/brand/analytics/clicks/timeseries` | Timeseries |

## Commission Groups — `client.commission_groups`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_commission_groups()` | GET | `/v3/network/{networkId}/commission-groups` | List commission groups |

## Commissions — `client.commissions`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_commissions()` | GET | `/v2/campaigns/{campaignId}/commissions` | List Commissions |
| `create_commission()` | POST | `/v2/campaigns/{campaignId}/commissions` | Create Commission |
| `get_commission()` | GET | `/v2/campaigns/{campaignId}/commissions/{commissionId}` | Get Commission |
| `update_commission()` | PATCH | `/v2/campaigns/{campaignId}/commissions/{commissionId}` | Update Commission |
| `migrate_commission()` | POST | `/v2/campaigns/{campaignId}/commissions/{commissionId}/migrate` | Migrate Commission |
| `retire_commission()` | POST | `/v2/campaigns/{campaignId}/commissions/{commissionId}/retire` | Retire Commission |

## Commissions CSV Download — `client.commissions_csv_download`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_commission_csv_download()` | GET | `/v2/campaigns/{campaignId}/commissions/all.csv` | CSV Download. |

## Communication Templates — `client.communication_templates`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_communication_template()` | GET | `/v2/communication-templates` | Get a list of communication templates |
| `create_communication_template()` | POST | `/v2/communication-templates` | Creates a new communication template |
| `read_communication_template()` | GET | `/v2/communication-templates/{id}` | Get a single communication template |
| `patch_communication_template()` | PATCH | `/v2/communication-templates/{id}` | Updates a communication template |
| `delete_communication_template()` | DELETE | `/v2/communication-templates/{id}` | Delete a single communication template |
| `fetch_communication_template_thumbnail()` | GET | `/v2/communication-templates/{id}/thumbnail` | Get a single communication template's thumbnail |

## Communications — `client.communications`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_communications()` | GET | `/v2/communications` | List communications |
| `create_communication()` | POST | `/v2/communications` | Creates a new draft communication |
| `get_communication()` | GET | `/v2/communications/{id}` | Retrieves a single communication |
| `update_communication()` | PUT | `/v2/communications/{id}` | Updates a draft communication |
| `delete_communication()` | DELETE | `/v2/communications/{id}` | Deletes an existing draft communication |
| `get_communication_content()` | GET | `/v2/communications/{id}/content` | Returns the content of a communication |
| `update_communication_content()` | PUT | `/v2/communications/{id}/content` | Updates the content of a communication |
| `send_communication_preview()` | POST | `/v2/communications/send-preview` | Sends a communication preview |
| `send_communication()` | POST | `/v2/communications/{id}/send` | Sends or schedules a draft communication |
| `cancel_communication()` | DELETE | `/v2/communications/{id}/cancel` | Cancels a scheduled communication |
| `get_communicatons_report()` | GET | `/v2/communications/summary` | Communications summary report |

## Conversion Metrics — `client.conversion_metrics`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_conversion_metrics()` | GET | `/reference/conversion_metric` | List Conversion Metrics |

## Conversion Types — `client.conversion_types`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_conversion_type()` | GET | `/reference/conversion_type` | List Conversion Type |

## Conversions — `client.conversions`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `post_conversions_count()` | POST | `/v3/brand/analytics/conversions/count` | Count |
| `post_conversions_explode()` | POST | `/v3/brand/analytics/conversions/explode` | Explode |
| `post_conversions_filter()` | POST | `/v3/brand/analytics/conversions/filter` | Filter |
| `post_conversions_timeseries()` | POST | `/v3/brand/analytics/conversions/timeseries` | Timeseries |

## Countries — `client.countries`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_countries()` | GET | `/reference/country` | List all Countries |

## Creatives — `client.creatives`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_creatives_for_a_campaign()` | GET | `/campaign/{campaign_id}/creative` | List all Creatives for a Campaign |
| `create_campaign_creatives()` | POST | `/campaign/{campaign_id}/creative` | Create Campaign Creatives |
| `update_campaign_creatives()` | PUT | `/campaign/{campaign_id}/creative` | Update Campaign Creatives |
| `list_all_creative_tags_for_campaign()` | GET | `/campaign/{campaign_id}/creative/tags` | List all Creative Tags for Campaign |
| `create_campaign_creative_tags()` | POST | `/campaign/{campaign_id}/creative/tags` | Create Campaign Creative Tags |
| `update_campaign_creative_tags()` | PUT | `/campaign/{campaign_id}/creative/tags` | Update Campaign Creative Tags |
| `delete_campaign_creative_tags()` | DELETE | `/campaign/{campaign_id}/creative/tags` | Delete Campaign Creative Tags |
| `list_all_creatives_for_a_campaign_by_tags()` | GET | `/campaign/{campaign_id}/creative_tags/creative` | List all Creatives for a Campaign by Tags |

## Currencies — `client.currencies`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_currencies()` | GET | `/reference/currency` | List all Currencies |

## Currency countries — `client.currency_countries`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_country_currency_combinations()` | GET | `/reference/currency/country` | List Country Currency Combinations |

## Current User — `client.current_user`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `update_current_user()` | PATCH | `/v3/brand/user` | Update Current user |

## Custom Terms and Conditions — `client.custom_terms_and_conditions`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_terms_and_conditions_for_a_given_campaign()` | GET | `/campaign/{campaign_id}/custom_terms/` | List All Custom Terms and Conditions for given campaign |
| `create_custom_terms_and_conditions()` | POST | `/campaign/{campaign_id}/custom_terms/` | Create Custom Terms and Conditions |
| `read_partner_campaign_custom_terms()` | GET | `/campaign/{campaign_id}/custom_terms/publisher/{publisher_id}` | List Partner's Terms and Conditions for a capaign. |
| `delete_campaign_custom_terms()` | DELETE | `/campaign/{campaign_id}/custom_terms/{custom_terms_id}` | Delete specific Custom Terms and Conditions |
| `create_assoc_campaign_custom_terms()` | POST | `/campaign/{campaign_id}/custom_terms/custom_terms_id/association` | Associate Custom Terms and Conditions with Partners |
| `delete_assoc_campaign_custom_terms()` | DELETE | `/campaign/{campaign_id}/custom_terms/custom_terms_id/association` | Remove associations between the Custom Terms and Conditions and Partners |

## Deals — `client.deals`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_campaign_deals()` | GET | `/campaign/{campaign_id}/deal` | List all Campaign Deals |
| `create_a_campaign_deal()` | POST | `/campaign/{campaign_id}/deal` | Create a Campaign Deal |
| `retrieve_a_campaign_deal()` | GET | `/campaign/{campaign_id}/deal/{deal_id}` | Retrieve a Campaign Deal |
| `update_a_campaign_deal()` | PATCH | `/campaign/{campaign_id}/deal/{deal_id}` | Update a Campaign Deal |
| `delete_a_campaign()` | DELETE | `/campaign/{campaign_id}/deal/{deal_id}` | Delete a Campaign |

## Deep link domains — `client.deep_link_domains`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_deeplink_domains()` | GET | `/v3/brand/{brand}/deeplink-domains` | Fetches allowed deeplink domains for the given brand. |
| `add_deeplink_domains()` | PATCH | `/v3/brand/{brand}/deeplink-domains` | Adds allowed deeplink domains for the given brand. |
| `delete_deeplink_domains()` | DELETE | `/v3/brand/{brand}/deeplink-domains` | Removes allowed deeplink domains for the given brand. |

## Devices — `client.devices`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_devices()` | GET | `/reference/device` | List all Devices |

## Discovery Settings — `client.discovery_settings`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_marketplace_brands()` | GET | `/v2/networks/{networkId}/marketplace/settings/advertisers` | List discovery settings for brands |
| `update_marketplace_brands()` | PUT | `/v2/networks/{networkId}/marketplace/settings/advertisers` | Update Brand Marketplace settings |

## Exclusive Code — `client.exclusive_code`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_v2_attribution_exclusive_codes()` | GET | `/v2/campaigns/{campaignId}/attribution/exclusive-codes` | List All Exclusive Codes |
| `post_v2_campaigns_campaign_id_attribution_exclusive_codes()` | POST | `/v2/campaigns/{campaignId}/attribution/exclusive-codes` | Create an Exclusive Code |
| `bulk_delete_v2_campaigns_campaign_id_attribution_exclusive_codes()` | DELETE | `/v2/campaigns/{campaignId}/attribution/exclusive-codes` | Delete Exclusive Codes |
| `get_campaigns_campaign_id_attribution_exclusive_codes_id()` | GET | `/v2/campaigns/{campaignId}/attribution/exclusive-codes/{id}` | Get an Exclusive Code |
| `patch_v2_campaigns_campaign_id_attribution_exclusive_codes_id()` | PATCH | `/v2/campaigns/{campaignId}/attribution/exclusive-codes/{id}` | Update an Exclusive Code |
| `delete_campaigns_campaign_id_attribution_exclusive_codes_id()` | DELETE | `/v2/campaigns/{campaignId}/attribution/exclusive-codes/{id}` | Delete an Exclusive Code |

## Exports — `client.exports`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `export_clicks()` | GET | `/reporting/export/export/click.csv` | Export a Clicks Report |
| `export_conversions()` | GET | `/reporting/export/export/conversion.csv` | Export Conversions Report |
| `export_conversion_items()` | GET | `/reporting/export/export/conversion_item.csv` | Export Conversion Items Report |

## Filter Sets — `client.filter_sets`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `delete_campaign_group_saved_report()` | DELETE | `/report/campaign_group/{campaign_group_id}/filter_sets/{filter_set_id}` | Delete a Campaign Group Saved Report |

## Impressions — `client.impressions`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `post_impressions_count()` | POST | `/v3/brand/analytics/impressions/count` | Count |
| `post_impressions_explode()` | POST | `/v3/brand/analytics/impressions/explode` | Explode |
| `post_impressions_filter()` | POST | `/v3/brand/analytics/impressions/filter` | Filter |
| `post_impressions_timeseries()` | POST | `/v3/brand/analytics/impressions/timeseries` | Timeseries |

## In-Cart — `client.in_cart`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_v2_attribution_in_cart()` | GET | `/v2/campaigns/{campaignId}/attribution/in-cart` | List In-Cart Settings |
| `post_v2_attribution_in_cart()` | PATCH | `/v2/campaigns/{campaignId}/attribution/in-cart` | Update In-Cart Settings |

## Incidents — `client.incidents`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_incidents()` | GET | `/v2/campaigns/{campaign_id}/fraud/incidents` | List Incidents |
| `get_incident()` | GET | `/v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}` | Get Incident |
| `delete_incident()` | DELETE | `/v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}` | Delete Incident |
| `get_incidents_aggregation()` | GET | `/v2/campaigns/{campaign_id}/fraud/incidents-aggregation` | Get Incidents Aggregation |
| `fraud_reject_partner()` | POST | `/v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}/reject-partner` | Reject Partner |
| `fraud_reject_conversions()` | POST | `/v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}/reject-conversions` | Reject Fraudulent Conversions |
| `fraud_pend_conversions()` | POST | `/v2/campaigns/{campaign_id}/fraud/incidents/{incident_id}/pend-conversions` | Set Incident Conversion status to Pending |
| `get_incident_partners()` | GET | `/v2/campaigns/{campaign_id}/fraud/incident-partners` | List Incident-partners |

## Invoices — `client.invoices`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_invoices()` | GET | `/user/advertiser/{advertiser_id}/invoice` | List all Invoices |
| `retrieve_an_invoice()` | GET | `/user/advertiser/{advertiser_id}/invoice/{invoice_id}` | Retrieve an Invoice |

## Jobs — `client.jobs`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_jobs()` | GET | `/v3/jobs` | Get a list of jobs for the user |
| `get_job()` | GET | `/v3/jobs/{jobID}` | Get a single job |
| `get_job_tasks()` | GET | `/v3/jobs/{jobID}/tasks` | Get tasks for a job |
| `get_task()` | GET | `/v3/jobs/{jobID}/tasks/{taskID}` | Get detailed task information |
| `replay_job()` | POST | `/v3/jobs/{jobID}/replay` | Replay a job |
| `replay_job_post()` | POST | `/v3/jobs/{jobID}/tasks/{taskID}/replay` | Replay a job |

## Jobs (v1) — `client.jobs_v1`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_job_v1()` | GET | `/job/{jobID}` | Get a single job (v1) |

## Locales — `client.locales`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_locales()` | GET | `/reference/locale` | List all Locales |

## Meta Attributes — `client.meta_attributes`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_meta_attributes_for_campaign()` | GET | `/campaign/{campaign_id}/meta` | List all Meta attributes for Campaign |

## Meta Fields — `client.meta_fields`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_meta_fields()` | GET | `/v2/campaigns/{campaignId}/meta-fields` | List Campaign Meta Fields |
| `get_tier_meta_fields()` | GET | `/v2/campaigns/{campaignId}/commissions/tiers/meta-fields` | List Tier Meta Fields |

## Metrics — `client.metrics`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_fraud_metrics()` | GET | `/v2/campaigns/{campaign_id}/fraud/metrics` | List Metrics |

## Network Partners — `client.network_partners`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `create_network_partners()` | POST | `/user/publisher` | Create network partner |
| `create_network_user_partners()` | POST | `/user` | Create network partner with user account |
| `list_all_partners_on_the_network()` | GET | `/network/{network_id}/publisher` | List all Partners on the Network |
| `update_partners_network_status()` | POST | `/network/{network_id}/publisher` | Update Partner's Network status |

## Network Terms and Conditions — `client.network_terms_and_conditions`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_network_terms_and_conditions()` | GET | `/reference/terms/{locale}/{country}/{network_id}` | List all terms and conditions for a network |

## Network Terms and Conditions (v3) — `client.network_terms_and_conditions_v3`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_network_terms_and_conditions()` | GET | `/v3/brand/network-terms-and-conditions` | List network terms and conditions |

## Network Terms and Conditions Acknowledgments (v3) — `client.network_terms_and_conditions_acknowledgments_v3`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `create_network_terms_and_conditions_acknowledgment()` | POST | `/v3/brand/network-terms-and-conditions-acknowledgments` | Create network terms and conditions acknowledgment |

## Networks — `client.networks`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_networks()` | GET | `/network` | List Networks |

## Paid Search Violations — `client.paid_search_violations`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_paid_search_violations()` | GET | `/v3/brand/participations/{participationId}/paid_search_violation` | List paid search violations |
| `create_a_paid_search_violation()` | POST | `/v3/brand/participations/{participationId}/paid_search_violation` | Create a paid search violation |
| `delete_a_paid_search_violation()` | DELETE | `/v3/brand/participations/{participationId}/paid_search_violation/{paidSearchViolationId}` | Delete a paid search violation |

## Participating Partners — `client.participating_partners`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_participating_partners()` | GET | `/campaign/{campaign_id}/publisher` | List all Participating Partners |
| `update_partner_participation()` | POST | `/campaign/{campaign_id}/publisher` | Update a Partner Participation on a Campaign |
| `retrieve_a_participating_partner()` | GET | `/campaign/{campaign_id}/publisher/{publisher_id}` | Retrieve a Participating Partner |

## Partner Commissions — `client.partner_commissions`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_publisher_commissions()` | GET | `/v2/campaigns/{campaignId}/publishers/{publisherId}/commissions` | Get Partner Commissions |
| `get_publisher_commissions_default()` | GET | `/v2/campaigns/{campaignId}/publishers/{publisherId}/commissions/default` | Get Partner Default Commissions |
| `get_publisher_commissions_campaign()` | GET | `/v2/campaigns/{campaignId}/publishers/{publisherId}/commissions/campaign` | List Partner Commissions For Specific Campaign |
| `get_publisher_commissions_voucher()` | GET | `/v2/campaigns/{campaignId}/publishers/{publisherId}/commissions/voucher` | List Partner Voucher Commissions For Specific Campaign |
| `get_publisher_commissions_promotion()` | GET | `/v2/campaigns/{campaignId}/publishers/{publisherId}/commissions/promotion` | List Partner Promotional Commissions For Specific Campaign |
| `get_publisher_commissions_tier()` | GET | `/v2/campaigns/{campaignId}/publishers/{publisherId}/commissions/tier` | List Partner Tiered Commissions For Specific Campaign |
| `get_active_publisher_commissions()` | GET | `/v2/campaigns/{campaignId}/publishers/{publisherId}/commissions/active` | List Active Partner Commissions |

## Partner Groups — `client.partner_groups`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_partner_groups()` | GET | `/campaign/{campaign_id}/commission_group` | List all Partner (Commission) Groups for a given campaign |
| `retrieve_a_partner_group()` | GET | `/campaign/{campaign_id}/commission_group/{commission_group_id}` | Retrieve a Partner (Commission) Group |
| `create_partner_groups()` | POST | `/commission_group` | Create Partner (Commission) Groups |
| `update_partner_commission_groups()` | PUT | `/commission_group` | Update Partner (Commission) Groups |

## Partner Whitelisting — `client.partner_whitelisting`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_whitelisted_partners()` | GET | `/v2/campaigns/{campaign_id}/fraud/whitelisted-partners` | Get Whitelisted Partners |
| `fraud_whitelist_partner()` | POST | `/v2/campaigns/{campaign_id}/fraud/whitelisted-partners` | Whitelist Partner |
| `delete_whitelisted_partner()` | DELETE | `/v2/campaigns/{campaign_id}/fraud/whitelisted-partners` | Remove Partner from Whitelist |

## Partnerize Tag Features — `client.partnerize_tag_features`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_partnerize_tag_features()` | GET | `/v3/brand/partnerize-tags/features` | List Available Partnerize Tag Features |
| `list_partnerize_tag_enabled_features()` | GET | `/v3/brand/partnerize-tags/{tagId}/features` | List Partnerize Tag Enabled Features |
| `enable_partnerize_tag_feature()` | POST | `/v3/brand/partnerize-tags/{tagId}/features` | Enable Feature on Partnerize Tag |
| `disable_partnerize_tag_feature()` | DELETE | `/v3/brand/partnerize-tags/{tagId}/features/{featureName}` | Disable Feature on Partnerize Tag |

## Partnerize Tags — `client.partnerize_tags`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_partnerize_tags()` | GET | `/v3/brand/partnerize-tags` | List Partnerize Tags |
| `create_partnerize_tag()` | POST | `/v3/brand/partnerize-tags` | Create Partnerize Tag |
| `get_partnerize_tag()` | GET | `/v3/brand/partnerize-tags/{partnerizeTagId}` | Get Partnerize Tag |
| `update_partnerize_tag()` | PATCH | `/v3/brand/partnerize-tags/{partnerizeTagId}` | Update Partnerize Tag |
| `delete_partnerize_tag()` | DELETE | `/v3/brand/partnerize-tags/{partnerizeTagId}` | Delete Partnerize Tag |

## Partnership Models — `client.partnership_models`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_partnership_models()` | GET | `/reference/partnership_model` | List Partnership Models |

## Placeholders — `client.placeholders`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_communication_placeholders()` | GET | `/v2/communication-placeholders` | Placeholders list |

## Platform Communications — `client.platform_communications`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_platform_communication_events()` | GET | `/v2/platform-communications/events` | Get platform events list |
| `get_platform_communications()` | GET | `/v2/platform-communications` | Get platform communications list |
| `create_platform_communication()` | POST | `/v2/platform-communications` | Create platform communication |
| `update_platform_communication()` | PATCH | `/v2/platform-communications/{id}` | Update an existing platform communication content |
| `delete_platform_communication()` | DELETE | `/v2/platform-communications/{id}` | Deletes an existing platform communication |
| `get_platform_communication_content()` | GET | `/v2/platform-communications/{id}/content` | Returns the content of a platform communication |
| `validate_platform_communication_content()` | POST | `/v2/platform-communications/validate-content` | Validate content |

## Preferred Partner — `client.preferred_partner`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_v2_attribution_preferred_partner()` | GET | `/v2/campaigns/{campaignId}/attribution/preferred-partners` | List All Preferred Partners |
| `post_v2_campaigns_campaign_id_attribution_preferred_partners()` | POST | `/v2/campaigns/{campaignId}/attribution/preferred-partners` | Create Preferred Partner |
| `bulk_delete_v2_campaigns_campaign_id_attribution_preferred_partners()` | DELETE | `/v2/campaigns/{campaignId}/attribution/preferred-partners` | Delete Preferred Partners |
| `get_v2_campaigns_campaign_id_attribution_preferred_partners_id()` | GET | `/v2/campaigns/{campaignId}/attribution/preferred-partners/{id}` | Get a Preferred Partner |
| `patch_v2_campaigns_campaign_id_attribution_preferred_partners_id()` | PATCH | `/v2/campaigns/{campaignId}/attribution/preferred-partners/{id}` | Update a Preferred Partner |
| `delete_v2_campaigns_campaign_id_attribution_preferred_partners_id()` | DELETE | `/v2/campaigns/{campaignId}/attribution/preferred-partners/{id}` | Delete a Preferred Partner |

## Product Feeds — `client.product_feeds`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_product_feeds()` | GET | `/campaign/{campaign_id}/feed` | List all Product Feeds for a Campaign |
| `create_a_product_feed_for_a_campaign()` | POST | `/campaign/{campaign_id}/feed` | Create a Product Feed |
| `update_a_campaign_feed()` | PUT | `/campaign/{campaign_id}/feed` | Update a Product Feed for a Campaign |

## Promotional Commissions — `client.promotional_commissions`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_promotional_commissions()` | GET | `/v2/campaigns/{campaignId}/commissions/promotions` | List Promotional Commissions |
| `create_promotional_commission()` | POST | `/v2/campaigns/{campaignId}/commissions/promotions` | Create Promotional Commission |
| `get_promotional_commission()` | GET | `/v2/campaigns/{campaignId}/commissions/promotions/{promotionalId}` | Get Promotional Commission |
| `update_promotional_commission()` | PATCH | `/v2/campaigns/{campaignId}/commissions/promotions/{promotionalId}` | Modify Promotional Commission |
| `delete_promotional_commission()` | DELETE | `/v2/campaigns/{campaignId}/commissions/promotions/{promotionalId}` | Delete Promotional Commission |
| `retire_promotional_commission()` | POST | `/v2/campaigns/{campaignId}/commissions/promotions/{promotionalId}/retire` | Retire Promotional Commission |

## Promotional Methods — `client.promotional_methods`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_promotional_method()` | GET | `/reference/promotional_method` | List all Promotional Method |

## Publishers — `client.publishers`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_publishers()` | GET | `/v2/networks/{network_id}/publishers` | Get publishers list |
| `export_publishers()` | POST | `/v2/networks/{network_id}/publishers.csv` | Export publishers |
| `get_publisher_details()` | GET | `/v2/networks/{network_id}/publishers/{publisher_id}` | Get publisher details |
| `get_publishers_ids()` | GET | `/v2/networks/{network_id}/publishers/ids` | Get publishers ids list |
| `post_publisher_collection()` | POST | `/v2/networks/{network_id}/partner-collections` | Create publisher collection |
| `delete_publisher_collection()` | DELETE | `/v2/networks/{network_id}/partner-collections/{collection-id}` | Delete publisher collection |
| `post_publisher_collection_partners()` | POST | `/v2/networks/{network_id}/partner-collections/{collection-id}/partners` | Add publishers to a collection |
| `delete_publisher_collection_partners()` | DELETE | `/v2/networks/{network_id}/partner-collections/{collection-id}/partners` | Remove publishers from a collection |

## Reporting on Meta data — `client.reporting_on_meta_data`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_meta_reports_for_a_campaign()` | GET | `/campaign/{campaign_id}/reporting/meta/reports` | List all Meta Reports for a Campaign |
| `create_meta_report()` | POST | `/campaign/{campaign_id}/reporting/meta/reports` | Create a Meta Report for a Campaign |
| `retrieve_meta_report()` | GET | `/campaign/{campaign_id}/reporting/meta/reports/{report_id}` | Retrieve a Meta Report for a Campaign |
| `delete_meta_report()` | DELETE | `/campaign/{campaign_id}/reporting/meta/reports/{report_id}` | Delete a Meta Report for a Campaign |
| `view_meta_report_results()` | GET | `/campaign/{campaign_id}/reporting/meta/reports/{report_id}/results` | View the results of a Meta Report for a Campaign. |
| `list_meta_values()` | GET | `/campaign/{campaign_id}/reporting/meta/values` | List all Meta Values for a Campaign |
| `list_meta_whitelist_keys()` | GET | `/campaign/{campaign_id}/reporting/meta/whitelist` | List all Meta Whitelist Keys for a Campaign |

## Saved Reports — `client.saved_reports`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `retrieve_campaign_group_saved_report()` | GET | `/report/campaign_group/{campaign_group_id}/filter_sets/{filter_set_id}` | Retrieve a Campaign Group Saved Report |
| `update_campaign_group_saved_report()` | PUT | `/report/campaign_group/{campaign_group_id}/filter_sets/{filter_set_id}` | Update a Campaign Group Saved Report |

## Split — `client.split`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_v2_campaigns_campaign_id_attribution_split()` | GET | `/v2/campaigns/{campaignId}/attribution/split` | List Split Settings |
| `patch_v2_campaigns_campaign_id_attribution_split()` | PATCH | `/v2/campaigns/{campaignId}/attribution/split` | Update Split Settings |

## Suppressed Code — `client.suppressed_code`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_v2_attribution_suppressed_codes()` | GET | `/v2/campaigns/{campaignId}/attribution/suppressed-codes` | List All Suppressed Codes |
| `post_v2_campaigns_campaign_id_attribution_suppressed_codes()` | POST | `/v2/campaigns/{campaignId}/attribution/suppressed-codes` | Create a Suppressed Code |
| `bulk_delete_v2_campaigns_campaign_id_attribution_suppressed_codes()` | DELETE | `/v2/campaigns/{campaignId}/attribution/suppressed-codes` | Delete Suppressed Codes |
| `get_campaigns_campaign_id_attribution_suppressed_codes_id()` | GET | `/v2/campaigns/{campaignId}/attribution/suppressed-codes/{id}` | Get a Suppressed Code |
| `patch_v2_campaigns_campaign_id_attribution_suppressed_codes_id()` | PATCH | `/v2/campaigns/{campaignId}/attribution/suppressed-codes/{id}` | Update a Suppressed Code |
| `delete_campaigns_campaign_id_attribution_suppressed_codes_id()` | DELETE | `/v2/campaigns/{campaignId}/attribution/suppressed-codes/{id}` | Delete a Suppressed Code |

## Tiers — `client.tiers`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_commission_tiers()` | GET | `/v2/campaigns/{campaignId}/commissions/tiers` | List Commission Tiers |
| `create_commission_tier()` | POST | `/v2/campaigns/{campaignId}/commissions/tiers` | Create Commission Tier |
| `update_commission_tier()` | PATCH | `/v2/campaigns/{campaignId}/commissions/tiers/{tierId}` | Modify Commission Tier |
| `delete_commission_tier()` | DELETE | `/v2/campaigns/{campaignId}/commissions/tiers/{tierId}` | Delete Commission Tier |

## Timezones — `client.timezones`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_timezones()` | GET | `/reference/timezone` | List all Timezones |

## Traffic Sources — `client.traffic_sources`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_traffic_sources()` | GET | `/reference/traffic_source` | List Traffic Sources |

## Transaction Query Reasons — `client.transaction_query_reasons`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_transaction_query_reasons()` | GET | `/campaign/{campaign_id}/tq_reasons` | List Transaction Query Reasons for a Campaign |
| `create_a_transaction_query_reason()` | POST | `/campaign/{campaign_id}/tq_reasons` | Create a Transaction Query Reason for a Campaign |
| `delete_a_transaction_query_reason()` | POST | `/campaign/{campaign_id}/tq_reasons/{transaction_query_reason_id}/delete` | Delete a Transaction Query Reason for a Campaign |

## US States — `client.us_states`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_us_states()` | GET | `/reference/us_state` | List US States |

## User Contexts — `client.user_contexts`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_user_contexts()` | GET | `/reference/user_context` | List all User Contexts |

## Verticals — `client.verticals`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_verticals()` | GET | `/reference/vertical` | List all Verticals |

## Voucher Codes — `client.voucher_codes`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_all_voucher_codes()` | GET | `/campaign/{campaign_id}/voucher_code` | List all Campaign Voucher Codes |
| `create_voucher_codes()` | POST | `/campaign/{campaign_id}/voucher_code` | Create Voucher Codes |
| `update_voucher_codes()` | PUT | `/campaign/{campaign_id}/voucher_code` | Update Voucher Codes |
| `retrieve_a_voucher_code()` | GET | `/campaign/{campaign_id}/voucher_code/{voucher_code_id}` | Retrieve a Voucher Code |

## Voucher Commissions — `client.voucher_commissions`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `get_voucher_commissions()` | GET | `/campaign/{campaignId}/optimisation/voucher/commission` | List Voucher Commissions |
| `post_voucher_commission()` | POST | `/campaign/{campaignId}/optimisation/voucher/commission` | Create Voucher Commission |
| `get_voucher_commission()` | GET | `/campaign/{campaignId}/optimisation/voucher/commission/{commissionId}` | Show Voucher Commissions |
| `get_voucher_commissions_put()` | PUT | `/campaign/{campaignId}/optimisation/voucher/commission/{commissionId}` | Edit Voucher Commissions |
| `delete_voucher_commission()` | DELETE | `/campaign/{campaignId}/optimisation/voucher/commission/{commissionId}` | Delete Scheduled Voucher Commission |
| `retire_voucher_commission()` | POST | `/campaign/{campaignId}/optimisation/voucher/commission/{commissionId}/retire` | Retire Active Voucher Commission |

## Website Types — `client.website_types`

| Method | HTTP | Path | Summary |
|---|---|---|---|
| `list_website_types()` | GET | `/reference/website_type` | List Website Types |
